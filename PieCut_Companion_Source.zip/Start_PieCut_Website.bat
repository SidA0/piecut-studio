@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start_PieCut_Website.ps1"
pause
