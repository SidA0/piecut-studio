$ErrorActionPreference = 'Stop'
$siteRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
$pythonExe = $null
if ($pythonCommand -and $pythonCommand.Source -notlike '*\WindowsApps\*') {
    & $pythonCommand.Source -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' 2>$null
    if ($LASTEXITCODE -eq 0) { $pythonExe = $pythonCommand.Source }
}
if (-not $pythonExe) {
    $bundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
    if (-not (Test-Path -LiteralPath $bundledPython)) { throw 'Python 3.10+ is required. Install Python, then run this launcher again.' }
    $pythonExe = $bundledPython
}
$vendorPath = Join-Path (Split-Path -Parent $siteRoot) 'work\vendor'
if (Test-Path -LiteralPath (Join-Path $vendorPath 'OCP')) {
    $env:PYTHONPATH = "$vendorPath;$siteRoot" + $(if ($env:PYTHONPATH) { ";$env:PYTHONPATH" } else { '' })
}
& $pythonExe -c 'import OCP, numpy'
if ($LASTEXITCODE -ne 0) {
    Write-Host 'Installing required CAD engine...'
    & $pythonExe -m pip install -r (Join-Path $siteRoot 'PieCut_requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Could not install the CAD dependency.' }
}
& $pythonExe (Join-Path $siteRoot 'piecut_web.py')
