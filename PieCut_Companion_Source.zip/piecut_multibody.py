"""Split a multi-solid STEP, optimize shared pie-cut profiles, and package selected bodies."""
from __future__ import annotations

import csv
import json
import math
import shutil
import zipfile
from pathlib import Path

from OCP.BRepBndLib import BRepBndLib
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.Bnd import Bnd_Box
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPControl import STEPControl_Reader
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS

import kerf_tube as kt
import piecut_assembly as assembly
import piecut_jig as pc


def extract_bodies(path,folder):
    """Keep the source STEP's global placement and stable solid order."""
    path=Path(path);folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    reader=STEPControl_Reader()
    if reader.ReadFile(str(path))!=IFSelect_RetDone:raise ValueError('Cannot read STEP file')
    reader.TransferRoots();shape=reader.OneShape();explorer=TopExp_Explorer(shape,TopAbs_SOLID)
    bodies=[]
    while explorer.More():
        index=len(bodies)+1;solid=TopoDS.Solid_s(explorer.Current())
        target=folder/f'body_{index:03d}.step'
        info={'body':index,'label':f'Body {index}','step_path':str(target)}
        if not BRepCheck_Analyzer(solid).IsValid():
            info['supported']=False;info['error']='Invalid solid';bodies.append(info);explorer.Next();continue
        box=Bnd_Box();BRepBndLib.Add_s(solid,box);bounds=box.Get()
        info['bounds_mm']=[round(v,3) for v in bounds]
        info['volume_mm3']=pc.shape_volume(solid)
        pc.write_step(target,solid)
        try:
            segments,outer,inner=kt.read_tube(target)
            info.update({'supported':True,'outside_diameter_mm':2*outer,'wall_mm':outer-inner,
                         'bend_count':sum(s.kind=='arc' for s in segments),
                         'straight_count':sum(s.kind=='line' for s in segments),
                         'centerline_length_mm':sum(s.length for s in segments)})
        except Exception as exc:
            info.update({'supported':False,'error':str(exc)})
        bodies.append(info);explorer.Next()
    if not bodies:raise ValueError('STEP file contains no solids')
    return bodies


def select_bodies(bodies,selected):
    supported={b['body']:b for b in bodies if b['supported']}
    if selected is None:selected=list(supported)
    if not isinstance(selected,list) or not selected:raise ValueError('Select at least one supported body')
    if any(isinstance(i,bool) or not isinstance(i,int) or i not in supported for i in selected):
        raise ValueError('Selected body IDs must identify supported solids in this upload')
    if len(set(selected))!=len(selected):raise ValueError('Body selection contains duplicates')
    return [supported[i] for i in selected]


def contexts(bodies):
    result=[]
    for body in bodies:
        path=Path(body['step_path']);segments,outer,inner=kt.read_tube(path)
        result.append({'body':body['body'],'path':path,'segments':segments,'outer':outer,'inner':inner,
                       'end_normals':pc.source_end_normals(path,segments),
                       'bends':[s for s in segments if s.kind=='arc']})
    return result


def count_map(contexts,option,max_angle):
    if option is None or option=='':return [pc.counts_from_option(c['segments'],None,max_angle) for c in contexts]
    if isinstance(option,str) and len(contexts)==1:
        return [pc.counts_from_option(contexts[0]['segments'],option,max_angle)]
    if not isinstance(option,list) or len(option)!=len(contexts):
        raise ValueError('Provide one segment-count list for each selected body')
    counts=[]
    for c,row in zip(contexts,option):
        if not isinstance(row,list) or len(row)!=len(c['bends']) or any(isinstance(n,bool) or not isinstance(n,int) or not 1<=n<=100 for n in row):
            raise ValueError(f"Body {c['body']}: provide 1–100 segments for each bend")
        counts.append(row)
    return counts


def angle_map(contexts,counts,option):
    if option is None:return None
    if not isinstance(option,list) or len(option)!=len(contexts):
        raise ValueError('Provide one sector-angle plan for each selected body')
    for c,row,angles in zip(contexts,counts,option):
        pc.validate_bend_angles(c['segments'],row,angles)
    return option


def signature_match(a,b):
    return (abs(a[0]-b[0])<.02 and abs(a[1]-b[1])<.02 and
            abs(a[2]-b[2])<.02 and abs(a[3]-b[3])<.05 and
            abs(a[4]-b[4])<.05 and abs(a[5]-b[5])<.01)


def planned_signatures(context,counts,bend_angles_deg=None):
    nodes,axes,normals,_=pc.path_nodes(context['segments'],counts,context['end_normals'],bend_angles_deg)
    signatures=[];outer=context['outer'];inner=context['inner']
    for i,axis in enumerate(axes):
        start=math.degrees(math.acos(max(-1,min(1,kt.dot(normals[i],axis)))))
        end=math.degrees(math.acos(max(-1,min(1,kt.dot(axis,normals[i+1])))))
        if max(start,end)>45+1e-6:return None
        va=kt.sub(normals[i],kt.mul(axis,kt.dot(normals[i],axis)))
        vb=kt.sub(normals[i+1],kt.mul(axis,kt.dot(normals[i+1],axis)))
        relative=0.0 if kt.norm(va)<1e-7 or kt.norm(vb)<1e-7 else kt.dot(kt.unit(va),kt.unit(vb))
        signatures.append((2*outer,outer-inner,kt.dist(nodes[i],nodes[i+1]),min(start,end),max(start,end),relative))
    return signatures


def plan_metrics(contexts,counts,include_error=True,bend_angles=None):
    unique=[];total=0;rms_numerator=0;source_length=0;delta=0;maximum=0
    for bi,(c,row) in enumerate(zip(contexts,counts)):
        angles=bend_angles[bi] if bend_angles is not None else None
        sigs=planned_signatures(c,row,angles)
        if sigs is None:return None
        total+=sum(row)
        for signature in sigs:
            if not any(signature_match(signature,old) for old in unique):unique.append(signature)
        if include_error:
            error=pc.centerline_error(c['segments'],row,angles)
            length=error['source_centerline_length_mm'];source_length+=length
            rms_numerator+=error['centerline_rms_deviation_mm']**2*length
            maximum=max(maximum,error['centerline_max_deviation_mm'])
            delta+=error['centerline_length_delta_mm']
    result={'unique_cut_profiles':len(unique),'total_pie_cuts':total}
    if include_error:result.update({'centerline_rms_deviation_mm':math.sqrt(rms_numerator/source_length),
            'centerline_max_deviation_mm':maximum,'centerline_length_delta_mm':delta})
    return result


def trade_study(contexts,current_counts,max_angle,bend_angles=None):
    """Compare feasible uniform resolutions plus the active (possibly nonuniform) plan."""
    base=count_map(contexts,None,max_angle)
    candidates=[('Current plan',current_counts,bend_angles,True)]
    for extra in (0,1,2,4,8):
        proposal=[[min(100,n+extra) for n in row] for row in base]
        candidates.append((f'Auto +{extra}/bend',proposal,None,False))
    seen=set();options=[]
    for label,counts,angles,current in candidates:
        key=(tuple(tuple(row) for row in counts),
             None if angles is None else tuple(tuple(tuple(round(a,6) for a in bend) for bend in body) for body in angles))
        if key in seen:continue
        seen.add(key)
        metrics=plan_metrics(contexts,counts,bend_angles=angles)
        if metrics is None:continue
        weld=0.0;joints=0
        for bi,(c,row) in enumerate(zip(contexts,counts)):
            _,axes,_,_=pc.path_nodes(c['segments'],row,c['end_normals'],
                angles[bi] if angles is not None else None)
            for left,right in zip(axes,axes[1:]):
                turn=math.degrees(math.acos(max(-1,min(1,kt.dot(left,right)))))
                weld+=pc.seam_length_mm(c['outer'],turn/2);joints+=1
        options.append({'label':label,'current':current,'counts':counts,
                        'bend_angles_deg':angles,'weld_length_mm':weld,
                        'joint_count':joints,'piece_count':joints+len(contexts),**metrics})
    options.sort(key=lambda item:(item['weld_length_mm'],item['total_pie_cuts']))
    return {'options':options,'accuracy_basis':'Centerline RMS distance to the original arc and line path; smaller is more accurate.',
            'weld_basis':'Estimated full outside circumference of each miter joint.'}


def standard_sectors(sweep,pitch,max_angle):
    if sweep<=pitch:return [sweep]
    interior=math.floor(sweep/pitch)
    remainder=sweep-interior*pitch
    if abs(remainder)<.001:return [sweep/interior]*interior
    if remainder>=8 and remainder<=max_angle:return [pitch]*interior+[remainder]
    if pitch+remainder<=max_angle:return [pitch]*(interior-1)+[pitch+remainder]
    interior-=1
    if interior<1:return None
    end=(sweep-interior*pitch)/2
    angles=[end]+[pitch]*interior+[end]
    if any(a<=0 or a>max_angle+1e-7 for a in angles):return None
    return angles


def standard_end_sectors(sweep,pitch,max_angle,min_end_deg=8.0):
    """Use identical full sectors and at most one terminal remainder."""
    whole=min(100,math.floor((sweep+1e-8)/pitch))
    for n in range(whole,-1,-1):
        remainder=sweep-n*pitch
        if n and abs(remainder)<.001:
            angles=[pitch]*(n-1)+[sweep-pitch*(n-1)]
        elif n and min_end_deg<=remainder<=max_angle+1e-8:
            angles=[pitch]*n+[remainder]
        elif n==0 and sweep<=max_angle+1e-8:
            angles=[sweep]
        else:continue
        if len(angles)<=100 and all(0<a<=max_angle+1e-8 for a in angles):return angles
    return None


def radius_families(contexts):
    families=[]
    for bi,c in enumerate(contexts):
        for ji,s in enumerate(c['bends']):
            family=next((f for f in families if abs(f['radius_mm']-s.radius)<.02 and
                         abs(f['outside_diameter_mm']-2*c['outer'])<.02 and
                         abs(f['wall_mm']-(c['outer']-c['inner']))<.02),None)
            if family is None:
                family={'radius_mm':s.radius,'outside_diameter_mm':2*c['outer'],
                        'wall_mm':c['outer']-c['inner'],'members':[]}
                families.append(family)
            family['members'].append((bi,ji,s))
    return families


def standard_family_summary(contexts,counts,angles,family,pitch):
    signatures=[];pieces=[];short=[]
    cache={}
    for bi,ji,_ in family['members']:
        if bi not in cache:
            c=contexts[bi]
            nodes,_,_,meta=pc.path_nodes(c['segments'],counts[bi],c['end_normals'],angles[bi])
            cache[bi]=(nodes,meta,planned_signatures(c,counts[bi],angles[bi]))
        nodes,meta,sigs=cache[bi]
        if sigs is None:return None
        for i,m in enumerate(meta):
            if m['kind']!='pie' or m['bend']!=ji+1:continue
            if pitch is not None and 0<i<len(meta)-1 and all(
                near['kind']=='pie' and near['bend']==ji+1 and
                abs(near['sector_angle_deg']-pitch)<.005 for near in meta[i-1:i+2]):
                if not any(signature_match(sigs[i],old) for old in signatures):signatures.append(sigs[i])
            chord=kt.dist(nodes[i],nodes[i+1])
            if chord<2*contexts[bi]['outer']:
                short.append({'body':contexts[bi]['body'],'bend':ji+1,'piece':i+1,'chord_mm':chord})
            pieces.append((m,sigs[i]))
    standard=sum(any(signature_match(sig,old) for old in signatures) for _,sig in pieces)
    end=sum(m['kind']=='pie' and pitch is not None and abs(m['sector_angle_deg']-pitch)>=.005 for m,_ in pieces)
    return {'radius_mm':family['radius_mm'],'outside_diameter_mm':family['outside_diameter_mm'],
            'wall_mm':family['wall_mm'],'pitch_deg':pitch,'bend_count':len(family['members']),
            'bends':[f"B{contexts[bi]['body']}:{ji+1}" for bi,ji,_ in family['members']],
            'pie_piece_count':len(pieces),'standard_piece_count':standard,
            'end_piece_count':end,'transition_piece_count':len(pieces)-standard-end,
            'standard_profile_count':len(signatures),'standard_signatures':[list(s) for s in signatures],
            'short_piece_issues':short}


def standard_radius_plan(contexts,max_angle=27,profile_weight=5):
    """Experimental shared interior pitch for each compatible radius/stock family."""
    if not 0<max_angle<=60:raise ValueError('Maximum angle must be above 0 and at most 60°')
    if not 0<=profile_weight<=20:raise ValueError('Profile weight must be 0–20')
    families=radius_families(contexts)
    counts=count_map(contexts,None,max_angle)
    angles=[[[math.degrees(s.length/s.radius)/n]*n for s,n in zip(c['bends'],row)]
            for c,row in zip(contexts,counts)]
    chosen=[]
    for family in families:
        pitches={max_angle}
        for _,_,s in family['members']:
            sweep=math.degrees(s.length/s.radius)
            minimum=max(1,math.ceil(sweep/max_angle-1e-9))
            pitches.update(sweep/n for n in range(minimum,min(101,minimum+9)))
        candidates=[]
        for pitch in sorted(pitches):
            proposed_counts=[row[:] for row in counts]
            proposed_angles=[[sector[:] for sector in body] for body in angles]
            for bi,ji,s in family['members']:
                sectors=standard_end_sectors(math.degrees(s.length/s.radius),pitch,max_angle)
                if sectors is None:break
                proposed_counts[bi][ji]=len(sectors);proposed_angles[bi][ji]=sectors
            else:
                metrics=plan_metrics(contexts,proposed_counts,include_error=False,bend_angles=proposed_angles)
                if metrics is None:continue
                summary=standard_family_summary(contexts,proposed_counts,proposed_angles,family,pitch)
                if summary is None or not summary['standard_piece_count']:continue
                custom=summary['pie_piece_count']-summary['standard_piece_count']
                score=(profile_weight*metrics['unique_cut_profiles']+metrics['total_pie_cuts']+
                       2*custom+3*max(0,summary['standard_profile_count']-1),
                       -summary['standard_piece_count'],metrics['unique_cut_profiles'])
                candidates.append((score,proposed_counts,proposed_angles,pitch))
        if candidates:
            _,counts,angles,pitch=min(candidates,key=lambda item:item[0])
        else:pitch=None
        chosen.append(pitch)
    metrics=plan_metrics(contexts,counts,bend_angles=angles)
    if metrics is None:raise ValueError('No standard-radius plan satisfies the miter limit')
    summaries=[standard_family_summary(contexts,counts,angles,f,pitch) for f,pitch in zip(families,chosen)]
    return {'experimental':True,'enabled':True,'counts':counts,'bend_angles_deg':angles,
            'families':summaries,'standard_piece_count':sum(s['standard_piece_count'] for s in summaries),
            'custom_pie_piece_count':sum(s['pie_piece_count']-s['standard_piece_count'] for s in summaries),
            'short_piece_issues':[issue for s in summaries for issue in s['short_piece_issues']],
            **metrics}


def optimize(contexts,max_angle=27,profile_weight=5,extra_segments=4):
    """Bounded multi-start coordinate search with global pitch seeds."""
    if not 0<=profile_weight<=20:raise ValueError('Profile weight must be 0–20')
    if not 0<=extra_segments<=8:raise ValueError('Extra segment search must be 0–8')
    base=[pc.counts_from_option(c['segments'],None,max_angle) for c in contexts]
    flat=[(bi,ji,s) for bi,c in enumerate(contexts) for ji,s in enumerate(c['bends'])]
    if not flat:raise ValueError('Selected bodies contain no circular bends')
    choices=[]
    for bi,ji,s in flat:
        minimum=max(1,math.ceil(math.degrees(s.length/s.radius)/max_angle-1e-9))
        maximum=min(100,max(minimum,base[bi][ji])+extra_segments)
        choices.append(list(range(minimum,maximum+1)))
    def matrix(vector):
        result=[row[:] for row in base]
        for (bi,ji,_),n in zip(flat,vector):result[bi][ji]=n
        return result
    cache={}
    def evaluate(vector):
        key=tuple(vector)
        if key not in cache:cache[key]=plan_metrics(contexts,matrix(vector),False)
        return cache[key]
    def score(metrics,weight):return (weight*metrics['unique_cut_profiles']+metrics['total_pie_cuts'],metrics['unique_cut_profiles'],metrics['total_pie_cuts'])
    seeds=[tuple(base[bi][ji] for bi,ji,_ in flat),tuple(option[0] for option in choices)]
    pitches={round(math.degrees(s.length/s.radius)/n,3) for (_,_,s),options in zip(flat,choices) for n in options}
    pitches=sorted(pitches)
    if len(pitches)>24:pitches=[pitches[round(i*(len(pitches)-1)/23)] for i in range(24)]
    for pitch in pitches:
        seeds.append(tuple(min(options,key=lambda n:abs(math.degrees(s.length/s.radius)/n-pitch))
                           for (_,_,s),options in zip(flat,choices)))
    results={}
    for weight in sorted({0.0,profile_weight,5.0,10.0}):
        for seed in seeds:
            current=seed;current_metrics=evaluate(current)
            if current_metrics is None:continue
            for _ in range(3):
                changed=False
                for index,options in enumerate(choices):
                    candidates=[]
                    for n in options:
                        v=current[:index]+(n,)+current[index+1:]
                        m=evaluate(v)
                        if m is not None:candidates.append((score(m,weight),v,m))
                    if not candidates:continue
                    _,best,best_metrics=min(candidates)
                    if best!=current:current=best;current_metrics=best_metrics;changed=True
                if not changed:break
            results[current]=current_metrics
    plans=[{'counts':matrix(vector),'bend_angles_deg':None,'shared_pitch_deg':None,'metrics':metrics}
           for vector,metrics in results.items()]
    families=[]
    for index,(bi,ji,s) in enumerate(flat):
        c=contexts[bi]
        family=next((f for f in families if abs(f[0][2].radius-s.radius)<.02 and
                     abs(contexts[f[0][0]]['outer']-c['outer'])<.01 and
                     abs(contexts[f[0][0]]['inner']-c['inner'])<.01),None)
        if family is None:families.append([(bi,ji,s,index)])
        else:family.append((bi,ji,s,index))
    pitch_plans=0
    for family in families:
        for pitch in pitches:
            if pitch>max_angle:continue
            angles=[[ [math.degrees(s.length/s.radius)/n]*n for s,n in zip(c['bends'],row)]
                    for c,row in zip(contexts,base)]
            changed=False
            for bi,ji,s,index in family:
                sectors=standard_sectors(math.degrees(s.length/s.radius),pitch,max_angle)
                if sectors is None or len(sectors)>choices[index][-1]:continue
                if len(sectors)>1 and any(abs(a-pitch)<1e-5 for a in sectors):changed=True
                angles[bi][ji]=sectors
            if not changed:continue
            proposed=[[len(sectors) for sectors in body] for body in angles]
            metrics=plan_metrics(contexts,proposed,False,angles)
            if metrics is None:continue
            plans.append({'counts':proposed,'bend_angles_deg':angles,'shared_pitch_deg':pitch,'metrics':metrics})
            pitch_plans+=1
    if not plans:raise ValueError('No cut plan satisfies the 45° miter limit')
    ranked=sorted(plans,key=lambda plan:score(plan['metrics'],profile_weight))
    preferred=ranked[0]
    fewest_profiles=min(plans,key=lambda plan:(plan['metrics']['unique_cut_profiles'],plan['metrics']['total_pie_cuts']))
    fewest_cuts=min(plans,key=lambda plan:(plan['metrics']['total_pie_cuts'],plan['metrics']['unique_cut_profiles']))
    precision=tuple(option[-1] for option in choices)
    candidates=[preferred,fewest_profiles,fewest_cuts]
    if evaluate(precision) is not None:candidates.append({'counts':matrix(precision),'bend_angles_deg':None,'shared_pitch_deg':None,'metrics':evaluate(precision)})
    candidates.extend(ranked)
    seen=set();alternatives=[]
    for item in candidates:
        key=(tuple(tuple(row) for row in item['counts']),
             None if item['bend_angles_deg'] is None else tuple(tuple(tuple(round(a,6) for a in sector) for sector in body) for body in item['bend_angles_deg']))
        if key not in seen:alternatives.append(item);seen.add(key)
        if len(alternatives)>=6:break
    def public(plan):return {'counts':plan['counts'],'bend_angles_deg':plan['bend_angles_deg'],
                             'shared_pitch_deg':plan['shared_pitch_deg'],
                             **plan_metrics(contexts,plan['counts'],True,plan['bend_angles_deg'])}
    return {'selected':public(preferred),
            'alternatives':[public(plan) for plan in alternatives],
            'baseline':{'counts':base,**(plan_metrics(contexts,base) or {})},
            'evaluated_plans':len(cache)+pitch_plans,'profile_weight':profile_weight,
            'extra_segments':extra_segments}


def global_profiles(contexts,reports,root,id_holes=False):
    groups=[]
    for c,report in zip(contexts,reports):
        for profile in report['cut_profiles']:
            signature=(report['outside_diameter_mm'],report['wall_mm'],profile['chord_length_mm'],
                       *profile['end_miters_deg'],profile['relative_bevel_orientation_dot'])
            group=None if id_holes else next((g for g in groups if signature_match(signature,g['_signature'])),None)
            if group is None:
                group={'profile':f'G{len(groups)+1:03d}','quantity':0,'positions':[],
                       'outside_diameter_mm':signature[0],'wall_mm':signature[1],
                       'chord_length_mm':signature[2],'end_miters_deg':[signature[3],signature[4]],
                       'relative_bevel_orientation_dot':signature[5],
                       'representative_step':f"body_{c['body']:03d}/{profile['quote_step']}",
                       '_signature':signature}
                groups.append(group)
            group['quantity']+=profile['quantity']
            group['positions'].extend(f"B{c['body']}:{number}" for number in profile['pieces'])
    folder=root/'unique_profiles';folder.mkdir(exist_ok=True)
    for group in groups:
        target=folder/f"{group['profile']}.step"
        shutil.copyfile(root/group['representative_step'],target)
        group['quote_step']=str(target.relative_to(root));del group['_signature']
    with (root/'global_cut_profiles.csv').open('w',newline='',encoding='utf-8') as file:
        writer=csv.writer(file)
        writer.writerow(['profile','quantity','positions','quote_step','OD_mm','wall_mm','chord_mm','start_miter_deg','end_miter_deg'])
        for g in groups:writer.writerow([g['profile'],g['quantity'],' '.join(g['positions']),g['quote_step'],
            f"{g['outside_diameter_mm']:.3f}",f"{g['wall_mm']:.3f}",f"{g['chord_length_mm']:.3f}",
            f"{g['end_miters_deg'][0]:.3f}",f"{g['end_miters_deg'][1]:.3f}"])
    return groups


def preview_data(contexts,counts,bend_angles=None):
    result=[]
    for bi,(c,row) in enumerate(zip(contexts,counts)):
        source=[]
        for s in c['segments']:
            if not source:source.append(list(s.start))
            steps=max(2,math.ceil(math.degrees(s.length/s.radius)/4)) if s.kind=='arc' else 1
            for j in range(1,steps+1):
                if s.kind=='line':point=s.end
                else:
                    fraction=j/steps
                    u=s.u0+(s.u1-s.u0)*fraction if s.forward else s.u1-(s.u1-s.u0)*fraction
                    point=kt.arc_point(s.center,s.radius,s.xdir,s.ydir,u)
                source.append(list(point))
        nodes,_,normals,meta=pc.path_nodes(c['segments'],row,c['end_normals'],
            bend_angles[bi] if bend_angles is not None else None)
        result.append({'body':c['body'],'outer_radius_mm':c['outer'],
                       'source_points':source,'pie_nodes':[list(p) for p in nodes],
                       'pie_normals':[list(n) for n in normals],
                       'piece_kind':[m['kind'] for m in meta]})
    return result


def generate_selected(contexts,counts,out_dir,max_angle=27,jig=False,id_holes=False,bend_angles=None,progress=None,standardization=None):
    out_dir=Path(out_dir);out_dir.mkdir(parents=True,exist_ok=True)
    reports=[]
    piece_total=sum(len(c['segments'])-len(c['bends'])+sum(row) for c,row in zip(contexts,counts))
    piece_offset=0
    for bi,(c,row) in enumerate(zip(contexts,counts)):
        target=out_dir/f"body_{c['body']:03d}"
        body_pieces=len(c['segments'])-len(c['bends'])+sum(row)
        def body_progress(phase,done,total):
            if not progress:return
            overall=piece_offset+done
            if phase=='cutting':
                fraction=.78*done/total
                label=f"Cutting body {c['body']} · piece {done} of {total}"
            else:
                stages={'comparing':'Comparing occupied volume','jig':'Building welding jig','exporting':'Exporting assembly'}
                fraction={'comparing':.82,'jig':.88,'exporting':.94}.get(phase,.94)
                label=f"Body {c['body']} · {stages.get(phase,phase)}"
            progress(label,5+85*(piece_offset+body_pieces*fraction)/piece_total,overall,piece_total)
        report=pc.generate(c['path'],target,segments_option=','.join(map(str,row)),max_angle=max_angle,
                           make_jig=jig,id_holes=id_holes,
                           bend_angles_deg=bend_angles[bi] if bend_angles is not None else None,
                           progress=body_progress)
        reports.append(report)
        piece_offset+=len(report['pieces'])
        if progress:progress(f"Body {c['body']} complete",5+85*piece_offset/piece_total,piece_offset,piece_total)
    if progress:progress('Building complete positioned assembly',91,piece_total,piece_total)
    assembly_path,assembly_body_count,assembly_piece_count=assembly.write_complete_assembly(
        out_dir,body_ids=[c['body'] for c in contexts])
    if assembly_body_count!=len(reports) or assembly_piece_count!=sum(r['piece_count'] for r in reports):
        raise RuntimeError('Complete assembly does not contain every generated body and piece')
    if progress:progress('Consolidating shared cut profiles',92,piece_total,piece_total)
    profiles=global_profiles(contexts,reports,out_dir,id_holes)
    if standardization is not None:
        for family in standardization['families']:
            ids=[]
            for profile in profiles:
                sig=(profile['outside_diameter_mm'],profile['wall_mm'],profile['chord_length_mm'],
                     *profile['end_miters_deg'],profile['relative_bevel_orientation_dot'])
                if any(signature_match(sig,old) for old in family['standard_signatures']):ids.append(profile['profile'])
            family['standard_profile_ids']=ids
        with (out_dir/'standard_radius_schedule.csv').open('w',newline='',encoding='utf-8') as file:
            writer=csv.writer(file)
            writer.writerow(['radius_mm','OD_mm','wall_mm','pitch_deg','bends','standard_profile_ids',
                             'standard_piece_qty','custom_end_piece_qty','transition_piece_qty'])
            for f in standardization['families']:
                writer.writerow([f"{f['radius_mm']:.3f}",f"{f['outside_diameter_mm']:.3f}",f"{f['wall_mm']:.3f}",
                    '' if f['pitch_deg'] is None else f"{f['pitch_deg']:.4f}",' '.join(f['bends']),
                    ' '.join(f['standard_profile_ids']),f['standard_piece_count'],f['end_piece_count'],
                    f['transition_piece_count']])
    lengths=[r['geometry_error']['source_centerline_length_mm'] for r in reports]
    length=sum(lengths);source_volume=sum(r['geometry_error']['source_wall_volume_mm3'] for r in reports)
    error={'source_centerline_length_mm':length,
           'pie_centerline_length_mm':sum(r['geometry_error']['pie_centerline_length_mm'] for r in reports),
           'centerline_length_delta_mm':sum(r['geometry_error']['centerline_length_delta_mm'] for r in reports),
           'centerline_rms_deviation_mm':math.sqrt(sum(r['geometry_error']['centerline_rms_deviation_mm']**2*l for r,l in zip(reports,lengths))/length),
           'centerline_max_deviation_mm':max(r['geometry_error']['centerline_max_deviation_mm'] for r in reports),
           'source_wall_volume_mm3':source_volume,
           'pie_wall_volume_mm3':sum(r['geometry_error']['pie_wall_volume_mm3'] for r in reports),
           'occupied_volume_error_mm3':sum(r['geometry_error']['occupied_volume_error_mm3'] for r in reports),
           'missing_source_volume_mm3':sum(r['geometry_error']['missing_source_volume_mm3'] for r in reports),
           'excess_pie_volume_mm3':sum(r['geometry_error']['excess_pie_volume_mm3'] for r in reports)}
    error['centerline_length_delta_percent']=100*error['centerline_length_delta_mm']/length
    error['occupied_volume_error_percent']=100*error['occupied_volume_error_mm3']/source_volume
    curves=[]
    for c,report in zip(contexts,reports):
        for curve in report['curve_profiles']:
            group=next((g for g in curves if abs(g['radius_mm']-curve['radius_mm'])<.02 and
                        abs(g['sweep_deg']-curve['sweep_deg'])<.05),None)
            if group is None:
                group={'profile':f'C{len(curves)+1:02d}','radius_mm':curve['radius_mm'],
                       'sweep_deg':curve['sweep_deg'],'bends':[],'quantity':0,'_counts':set()}
                curves.append(group)
            group['bends'].extend(f"B{c['body']}:{n}" for n in curve['bends'])
            group['quantity']+=curve['quantity'];group['_counts'].add(curve['segments_each'])
    for curve in curves:
        curve['segments_each']=', '.join(map(str,sorted(curve.pop('_counts'))))
    result={'multi_body':True,'selected_body_ids':[c['body'] for c in contexts],
            'body_count':len(contexts),'bodies':[{'body':c['body'],'report':r} for c,r in zip(contexts,reports)],
            'segments_per_body':counts,'bend_angles_per_body':bend_angles,
            'unique_curve_profile_count':len(curves),'curve_profiles':curves,
            'unique_cut_profile_count':len(profiles),'cut_profiles':profiles,
            'total_pie_cut_count':sum(r['total_pie_cut_count'] for r in reports),
            'piece_count':sum(r['piece_count'] for r in reports),
            'complete_assembly':{'step':assembly_path.name,'body_count':assembly_body_count,
                                 'piece_count':assembly_piece_count,
                                 'placement':'original STEP world coordinates; separate named solids'},
            'geometry_error':error,'weld':{'joint_count':sum(r['weld']['joint_count'] for r in reports),
            'expected_full_circumference_mm':sum(r['weld']['expected_full_circumference_mm'] for r in reports),
            'expected_half_circumference_mm':sum(r['weld']['expected_half_circumference_mm'] for r in reports)},
            'jig':{'enabled':jig,'experimental':True,'per_body':True},
            'standardization':standardization,
            'note':'Global profile groups share OD, wall, chord, both bevels and relative bevel orientation within the documented tolerances. Confirm interchangeability and laser-shop acceptance.'}
    (out_dir/'fabrication_report.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    (out_dir/'README.txt').write_text('Open all_piecuts_assembly.step for every selected body and every individually named piece in the original STEP world coordinates. Use global_cut_profiles.csv and unique_profiles/G###.step for quantity quoting. Body folders contain positioned parts, assemblies, optional one-piece jigs, and detailed reports. '+
        ('The experimental standard_radius_schedule.csv identifies the shared middle profiles and custom end/transition quantities. ' if standardization is not None else '')+
        'Check each assembly against the source STEP before fabrication.\n',encoding='utf-8')
    package=out_dir/'piecuts_multi_body.zip'
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
        for path in out_dir.rglob('*'):
            if path.is_file() and path!=package and path.name not in ('piecuts.zip','piecuts_and_jig.zip'):
                archive.write(path,path.relative_to(out_dir))
    return result
