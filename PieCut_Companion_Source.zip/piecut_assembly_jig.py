"""Inspect positioned tube pie cuts and build narrow, one-solid cradle jigs.

Each STEP solid must be one straight, hollow, round tube piece with two planar
end faces. Coordinates and reported lengths are millimeters.
"""
from __future__ import annotations

import json
import math
import zipfile
from pathlib import Path

import numpy as np
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace, BRepBuilderAPI_MakePolygon
from OCP.BRepGProp import BRepGProp
from OCP.BRepPrimAPI import BRepPrimAPI_MakeCylinder
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut, BRepAlgoAPI_Fuse
from OCP.BRepOffsetAPI import BRepOffsetAPI_ThruSections
from OCP.Bnd import Bnd_Box
from OCP.GProp import GProp_GProps
from OCP.GeomAbs import GeomAbs_Cylinder, GeomAbs_Plane
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPControl import STEPControl_Reader
from OCP.TopAbs import TopAbs_EDGE, TopAbs_FACE, TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS
from OCP.gp import gp_Ax2

import kerf_tube as kt
import piecut_jig as pc
import piecut_stl_repair


def _xyz(point): return (point.X(),point.Y(),point.Z())


def _end_faces(solid, axis_point, axis, radius):
    result=[]; exp=TopExp_Explorer(solid,TopAbs_FACE)
    while exp.More():
        face=TopoDS.Face_s(exp.Current());ad=BRepAdaptor_Surface(face)
        if ad.GetType()==GeomAbs_Plane:
            props=GProp_GProps();BRepGProp.SurfaceProperties_s(face,props)
            normal=_xyz(ad.Plane().Axis().Direction());alignment=abs(kt.dot(normal,axis))
            if alignment>.2:
                centroid=_xyz(props.CentreOfMass())
                along=kt.dot(normal,kt.sub(centroid,axis_point))/kt.dot(normal,axis)
                center=kt.add(axis_point,kt.mul(axis,along))
                lengths=[];edges=TopExp_Explorer(face,TopAbs_EDGE)
                while edges.More():
                    edge_props=GProp_GProps();BRepGProp.LinearProperties_s(TopoDS.Edge_s(edges.Current()),edge_props)
                    lengths.append(edge_props.Mass());edges.Next()
                if lengths and max(lengths)>3*radius:
                    result.append({'center':center,'normal':normal,'outer_seam_mm':max(lengths),
                                   'area_mm2':props.Mass(),'alignment':alignment})
        exp.Next()
    result.sort(key=lambda f:f['area_mm2'],reverse=True)
    if len(result)<2:raise ValueError('A solid has fewer than two planar tube end faces')
    pair=sorted(result[:2],key=lambda f:kt.dot(f['center'],axis))
    if kt.dist(pair[0]['center'],pair[1]['center'])<1:raise ValueError('Tube piece is shorter than 1 mm')
    return pair


def inspect(path):
    reader=STEPControl_Reader()
    if reader.ReadFile(str(path))!=IFSelect_RetDone:raise ValueError('Could not read assembly STEP file')
    reader.TransferRoots();shape=reader.OneShape();exp=TopExp_Explorer(shape,TopAbs_SOLID);pieces=[]
    while exp.More():
        solid=TopoDS.Solid_s(exp.Current());exp.Next();cylinders=[];faces=TopExp_Explorer(solid,TopAbs_FACE)
        while faces.More():
            face=TopoDS.Face_s(faces.Current());ad=BRepAdaptor_Surface(face)
            if ad.GetType()==GeomAbs_Cylinder:
                props=GProp_GProps();BRepGProp.SurfaceProperties_s(face,props)
                cy=ad.Cylinder();cylinders.append((cy.Radius(),props.Mass(),_xyz(cy.Axis().Location()),_xyz(cy.Axis().Direction())))
            faces.Next()
        if not cylinders:raise ValueError(f'Solid {len(pieces)+1} is not a straight round tube pie cut')
        outer,_,axis_point,axis=max(cylinders,key=lambda c:(c[0],c[1]))
        inner_candidates=[c[0] for c in cylinders if c[0]<outer-.05]
        if not inner_candidates:raise ValueError(f'Solid {len(pieces)+1} has no hollow bore')
        inner=max(inner_candidates)
        ends=_end_faces(solid,axis_point,axis,outer)
        box=Bnd_Box();BRepBndLib.Add_s(solid,box)
        pieces.append({'number':len(pieces)+1,'solid':solid,'outer_radius_mm':outer,
                       'inner_radius_mm':inner,'axis':axis,'ends':ends,
                       'center':kt.mul(kt.add(ends[0]['center'],ends[1]['center']),.5),
                       'length_mm':kt.dist(ends[0]['center'],ends[1]['center']),
                       'bounds_mm':list(box.Get())})
    if not pieces:raise ValueError('Assembly STEP contains no solids')
    if len(pieces)>200:raise ValueError('Assembly has over 200 solids; split it into smaller STEP files')
    ends=[(pi,ei,face) for pi,p in enumerate(pieces) for ei,face in enumerate(p['ends'])]
    candidates=[]
    for a in range(len(ends)):
        pi,ei,fa=ends[a]
        for b in range(a+1,len(ends)):
            pj,ej,fb=ends[b]
            if pi==pj:continue
            pa,pb=pieces[pi],pieces[pj]
            d=kt.dist(fa['center'],fb['center'])
            if d>max(.3,.02*min(pa['outer_radius_mm'],pb['outer_radius_mm'])):continue
            if abs(pa['outer_radius_mm']-pb['outer_radius_mm'])>.15:continue
            if abs(kt.dot(fa['normal'],fb['normal']))<.995:continue
            if abs(fa['outer_seam_mm']-fb['outer_seam_mm'])>max(.5,.01*fa['outer_seam_mm']):continue
            candidates.append((d,a,b))
    used=set();joints=[]
    for d,a,b in sorted(candidates):
        if a in used or b in used:continue
        used.update((a,b));pi,ei,fa=ends[a];pj,ej,fb=ends[b]
        joints.append({'piece_a':pi+1,'end_a':ei+1,'piece_b':pj+1,'end_b':ej+1,
                       'center_mm':list(kt.mul(kt.add(fa['center'],fb['center']),.5)),
                       'outside_weld_length_mm':(fa['outer_seam_mm']+fb['outer_seam_mm'])/2,
                       'face_gap_mm':d})
    parent=list(range(len(pieces)))
    def root(i):
        while parent[i]!=i:i=parent[i]
        return i
    for j in joints:parent[root(j['piece_b']-1)]=root(j['piece_a']-1)
    groups={}
    for i in range(len(pieces)):groups.setdefault(root(i),[]).append(i)
    components=list(groups.values())
    public={'units':'mm','piece_count':len(pieces),'joint_count':len(joints),
            'open_end_count':2*len(pieces)-2*len(joints),
            'connected_run_count':len(components),
            'outside_weld_length_mm':sum(j['outside_weld_length_mm'] for j in joints),
            'joints':joints,'pieces':[{'piece':p['number'],'outside_diameter_mm':2*p['outer_radius_mm'],
                                      'wall_mm':p['outer_radius_mm']-p['inner_radius_mm'],
                                      'length_mm':p['length_mm'],'center_mm':list(p['center'])} for p in pieces],
            'runs':[[i+1 for i in group] for group in components],
            'method':'Matched planar annular end faces; length follows the outside edge of each shared miter seam.',
            'limitations':'Only matching, coincident planar tube ends are counted. Open ends, gaps over tolerance, nonplanar joins, and branch welds are excluded.'}
    return pieces,components,public


def _print_up(pieces):
    points=np.array([face['center'] for piece in pieces for face in piece['ends']],float)
    centered=points-points.mean(axis=0)
    if len(points)>2:
        _,values,vh=np.linalg.svd(centered,full_matrices=False)
        up=vh[-1] if values[-1]<.05*max(values[0],1) else vh[-1]
    else:up=np.array([0.,0.,1.])
    if abs(np.dot(up,pieces[0]['axis']))>.9:up=np.array([0.,0.,1.]) if abs(pieces[0]['axis'][2])<.9 else np.array([1.,0.,0.])
    return tuple(float(v) for v in up/np.linalg.norm(up))


def _section(center,side,up,bottom_level,radius):
    half_width=radius+5
    foot=kt.add(center,kt.mul(up,bottom_level-kt.dot(center,up)))
    top=kt.add(center,kt.mul(up,.2*radius))
    corners=[kt.add(foot,kt.mul(side,-half_width)),
             kt.add(foot,kt.mul(side,half_width)),
             kt.add(top,kt.mul(side,half_width)),
             kt.add(top,kt.mul(side,-half_width))]
    wire=BRepBuilderAPI_MakePolygon()
    for corner in corners:wire.Add(pc.pnt(corner))
    wire.Close()
    return wire.Wire()


def _channel_blank(piece,up,bottom_level,terminal):
    a,b=piece['ends'];start,end=a['center'],b['center']
    axis=kt.unit(kt.sub(end,start));horizontal=kt.sub(axis,kt.mul(up,kt.dot(axis,up)))
    if kt.norm(horizontal)<.15:raise ValueError(f"Piece {piece['number']} is too close to the jig print direction")
    side=kt.unit(kt.cross(up,horizontal));radius=piece['outer_radius_mm']
    # Neighboring blocks overlap into a continuous channel. Terminal blocks
    # extend beyond the tube ends to leave solid, flat alignment stops.
    extension=max(4.,.6*radius)
    def stop_extension(face):
        alignment=max(.2,abs(kt.dot(axis,face['normal'])))
        bevel=math.sqrt(max(0.,1-alignment*alignment))/alignment
        return 4.+radius*bevel
    start_extension=stop_extension(a) if (piece['number'],1) in terminal else extension
    end_extension=stop_extension(b) if (piece['number'],2) in terminal else extension
    start=kt.sub(start,kt.mul(axis,start_extension));end=kt.add(end,kt.mul(axis,end_extension))
    loft=BRepOffsetAPI_ThruSections(True,True,1e-6)
    loft.AddWire(_section(start,side,up,bottom_level,radius))
    loft.AddWire(_section(end,side,up,bottom_level,radius))
    loft.Build()
    if not loft.IsDone():raise RuntimeError(f"Could not build channel blank for piece {piece['number']}")
    return loft.Shape()


def _tube_envelope(piece,clearance=.2,end_clearance=.25):
    a,b=piece['ends'];start,end=a['center'],b['center'];axis=kt.unit(kt.sub(end,start))
    radius=piece['outer_radius_mm']+clearance;length=piece['length_mm'];extra=radius+5
    cylinder=BRepPrimAPI_MakeCylinder(gp_Ax2(pc.pnt(kt.sub(start,kt.mul(axis,extra))),pc.direction(axis)),
                                     radius,length+2*extra).Shape()
    mid=kt.mul(kt.add(start,end),.5)
    first=pc.halfspace(kt.sub(start,kt.mul(axis,end_clearance)),a['normal'],mid)
    last=pc.halfspace(kt.add(end,kt.mul(axis,end_clearance)),b['normal'],mid)
    result=pc.bool_op(__import__('OCP.BRepAlgoAPI',fromlist=['BRepAlgoAPI_Common']).BRepAlgoAPI_Common,
                      cylinder,first,f"tube envelope {piece['number']} start")
    return pc.bool_op(__import__('OCP.BRepAlgoAPI',fromlist=['BRepAlgoAPI_Common']).BRepAlgoAPI_Common,
                      result,last,f"tube envelope {piece['number']} end")


def make_jigs(pieces,components,joints,out_dir,fit_clearance=.15,weld_access=4):
    out_dir=Path(out_dir);out_dir.mkdir(parents=True,exist_ok=True)
    generated=[];summaries=[]
    mates={(j['piece_a'],j['end_a']) for j in joints}|{(j['piece_b'],j['end_b']) for j in joints}
    for run,indices in enumerate(components,1):
        group=[pieces[i] for i in indices];up=_print_up(group)
        bottom_level=min(kt.dot(face['center'],up)-p['outer_radius_mm']-6
                         for p in group for face in p['ends'])
        terminal={(p['number'],end) for p in group for end in (1,2) if (p['number'],end) not in mates}
        blanks=[_channel_blank(p,up,bottom_level,terminal) for p in group]
        fixture=blanks[0]
        for i,blank in enumerate(blanks[1:],2):fixture=pc.bool_op(BRepAlgoAPI_Fuse,fixture,blank,f'channel blank {i}')
        for p in group:
            fixture=pc.bool_op(BRepAlgoAPI_Cut,fixture,_tube_envelope(p,fit_clearance),
                               f"tube channel {p['number']}")
        fixture,discarded=pc.largest_connected_solid(fixture)
        if discarded>1:raise RuntimeError(f'Run {run}: jig has {discarded:.1f} mm³ of disconnected material')
        pc.verify(fixture,f'run {run} one-piece cradle')
        step=out_dir/f'RUN_{run:02d}_ONE_PIECE_JIG.step';stl=out_dir/f'RUN_{run:02d}_ONE_PIECE_JIG.stl'
        pc.write_step(step,fixture);pc.write_stl(stl,fixture)
        patched=piecut_stl_repair.repair(stl)
        generated.extend((step,stl))
        box=Bnd_Box();BRepBndLib.Add_s(fixture,box);bounds=box.Get()
        summaries.append({'run':run,'piece_numbers':[i+1 for i in indices],
                          'part_count':1,'print_axis':list(up),
                          'flat_bottom_plane_mm':bottom_level,'terminal_stop_count':len(terminal),
                          'terminal_stop_thickness_mm':3.75,
                          'stl_patch_faces':patched,
                          'envelope_mm':[bounds[3+i]-bounds[i] for i in range(3)],
                          'step':step.name,'stl':stl.name})
    return summaries,generated


def package(path,out_dir,make_jig=True):
    path=Path(path);out_dir=Path(out_dir);out_dir.mkdir(parents=True,exist_ok=True)
    pieces,components,report=inspect(path)
    generated=[]
    if make_jig:
        report['jigs'],generated=make_jigs(pieces,components,report['joints'],out_dir)
    else:report['jigs']=[]
    report_path=out_dir/'assembly_weld_report.json';report_path.write_text(json.dumps(report,indent=2),encoding='utf-8')
    archive=out_dir/'assembly_weld_and_jigs.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(path,'uploaded_assembly'+path.suffix.lower())
        z.write(report_path,report_path.name)
        for p in generated:z.write(p,p.name)
    return report
