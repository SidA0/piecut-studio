"""Develop a constant-diameter, circular-arc STEP tube into a kerf-cut straight tube.

Requires Python 3.10+ and ``pip install cadquery-ocp==7.9.3.1.1``.
The output is a proposed fabrication model, not a structural or process approval.
"""
from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from OCP.BRep import BRep_Builder
from OCP.BRepAdaptor import BRepAdaptor_Curve, BRepAdaptor_Surface
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace, BRepBuilderAPI_MakePolygon
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepGProp import BRepGProp
from OCP.BRepPrimAPI import BRepPrimAPI_MakeCylinder, BRepPrimAPI_MakePrism
from OCP.BRepTools import BRepTools
from OCP.GProp import GProp_GProps
from OCP.GeomAbs import GeomAbs_BSplineSurface, GeomAbs_Circle, GeomAbs_Cylinder, GeomAbs_Plane, GeomAbs_Torus
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPControl import STEPControl_AsIs, STEPControl_Reader, STEPControl_Writer
from OCP.TopAbs import TopAbs_EDGE, TopAbs_FACE, TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS, TopoDS_Compound
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt, gp_Vec


def vec(p): return (p.X(), p.Y(), p.Z())
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def mul(a,k): return tuple(x*k for x in a)
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def norm(a): return math.sqrt(dot(a,a))
def unit(a): return mul(a,1/norm(a))
def dist(a,b): return norm(sub(a,b))
def rotate(v,axis,angle):
    return add(add(mul(v,math.cos(angle)),mul(cross(axis,v),math.sin(angle))),mul(axis,dot(axis,v)*(1-math.cos(angle))))
def close(a,b,tol=.02): return dist(a,b)<tol


@dataclass
class Segment:
    kind: str
    start: tuple
    end: tuple
    length: float
    radius: float = 0
    center: tuple = ()
    xdir: tuple = ()
    ydir: tuple = ()
    u0: float = 0
    u1: float = 0
    forward: bool = True

    def reversed(self):
        return Segment(self.kind,self.end,self.start,self.length,self.radius,self.center,self.xdir,self.ydir,self.u0,self.u1,not self.forward)

    def tangent_start(self):
        if self.kind=='line': return unit(sub(self.end,self.start))
        u=self.u0 if self.forward else self.u1
        t=add(mul(self.xdir,-math.sin(u)),mul(self.ydir,math.cos(u)))
        return t if self.forward else mul(t,-1)

    def tangent_end(self):
        if self.kind=='line': return unit(sub(self.end,self.start))
        u=self.u1 if self.forward else self.u0
        t=add(mul(self.xdir,-math.sin(u)),mul(self.ydir,math.cos(u)))
        return t if self.forward else mul(t,-1)


def arc_point(center,radius,xdir,ydir,u):
    return add(center,mul(add(mul(xdir,math.cos(u)),mul(ydir,math.sin(u))),radius))


def read_nurbs_tube(shape,faces):
    """Recover exact round sweep sections exported as rational B-spline patches.

    SOLIDWORKS can encode otherwise analytic tube walls as pairs of rational
    half-circle surfaces. The circular boundary edges provide stations; circle
    fits across each surface provide the intervening centerline.
    """
    wall_faces=[];radii=[];stations={}
    for face in faces:
        surface=BRepAdaptor_Surface(face)
        if surface.GetType()==GeomAbs_Plane:continue
        if surface.GetType()!=GeomAbs_BSplineSurface:
            raise ValueError('Mixed unsupported tube wall surfaces')
        explorer=TopExp_Explorer(face,TopAbs_EDGE);rings=[]
        while explorer.More():
            curve=BRepAdaptor_Curve(TopoDS.Edge_s(explorer.Current()))
            if curve.GetType()==GeomAbs_Circle:
                circle=curve.Circle();center=vec(circle.Location());radius=circle.Radius()
                key=tuple(round(x,3) for x in center)
                stations[key]=center;rings.append((key,radius));radii.append(radius)
            explorer.Next()
        if len(rings)!=2 or abs(rings[0][1]-rings[1][1])>.02 or rings[0][0]==rings[1][0]:
            raise ValueError('B-spline walls lack paired circular section edges')
        wall_faces.append((surface,BRepTools.UVBounds_s(face),rings))
    if not radii:raise ValueError('No round wall sections found')
    outer=max(radii);inner=min(radii)
    if inner<=0 or outer-inner<.1 or any(min(abs(r-outer),abs(r-inner))>.02 for r in radii):
        raise ValueError('Tube wall or diameter is not constant')
    spans=defaultdict(list);neighbors=defaultdict(set)
    for surface,uv,rings in wall_faces:
        a,b=rings[0][0],rings[1][0]
        key=tuple(sorted((a,b)));neighbors[a].add(b);neighbors[b].add(a)
        if abs(rings[0][1]-outer)<.02:spans[key].append((surface,uv))
    ends=[k for k,v in neighbors.items() if len(v)==1]
    if len(ends)!=2 or any(len(v)>2 for v in neighbors.values()):
        raise ValueError('Round sweep centerline is disconnected or branched')
    for pair,surfaces in spans.items():
        if len(surfaces)!=2:raise ValueError('Expected two outer half-circle patches per sweep section')
    order=[min(ends)];previous=None
    while order[-1]!=max(ends):
        next_nodes=neighbors[order[-1]]-{previous}
        if len(next_nodes)!=1:raise ValueError('Ambiguous sweep section ordering')
        previous=order[-1];order.append(next(iter(next_nodes)))
        if len(order)>len(stations):raise ValueError('Sweep station path loops')
    if len(order)!=len(stations):raise ValueError('Sweep centerline is disconnected')

    def section_center(surfaces,start,end,t):
        points=[]
        for surface,(u0,u1,v0,v1) in surfaces:
            # A face may reverse its longitudinal parameter. Score its first
            # boundary against the two known circular stations.
            probes=[np.array(vec(surface.Value(float(u),v0))) for u in np.linspace(u0,u1,3)]
            score=lambda c:sum((np.linalg.norm(p-c)-outer)**2 for p in probes)
            local_t=t if score(start)<score(end) else 1-t
            v=v0+(v1-v0)*local_t
            points.extend(vec(surface.Value(float(u),float(v))) for u in np.linspace(u0,u1,5))
        points=np.asarray(points);mean=points.mean(axis=0)
        _,_,basis=np.linalg.svd(points-mean)
        xy=(points-mean)@basis[:2].T
        rhs=np.sum(xy*xy,axis=1)
        center_xy=np.linalg.lstsq(np.c_[2*xy,np.ones(len(xy))],rhs,rcond=None)[0][:2]
        center=mean+center_xy@basis[:2]
        radial=np.linalg.norm(points-center,axis=1)
        if max(abs(radial-outer))>.05 or max(abs((points-mean)@basis[2]))>.05:
            raise ValueError('B-spline section is not a constant-radius circular tube')
        return center

    segments=[]
    for ka,kb in zip(order,order[1:]):
        surfaces=spans[tuple(sorted((ka,kb)))]
        p=np.asarray([section_center(surfaces,np.asarray(stations[ka]),np.asarray(stations[kb]),t)
                      for t in np.linspace(0,1,9)])
        start,end=p[0],p[-1]
        if np.linalg.norm(start-stations[ka])>.02 or np.linalg.norm(end-stations[kb])>.02:
            raise ValueError('B-spline section endpoints do not match their circular boundaries')
        chord=end-start;length=float(np.linalg.norm(chord))
        line=np.asarray([start+chord*t for t in np.linspace(0,1,9)])
        if max(np.linalg.norm(p-line,axis=1))<.02:
            segments.append(Segment('line',tuple(start),tuple(end),length));continue
        mid=(start+end)/2;offset=p[4]-mid
        along=chord/length;offset=offset-np.dot(offset,along)*along
        sag=float(np.linalg.norm(offset))
        if sag<.02:raise ValueError('Spline bend is too shallow to recover reliably')
        toward=offset/sag;radius=length*length/(8*sag)+sag/2
        center=mid+toward*(sag-radius)
        radial=np.linalg.norm(p-center,axis=1)
        normal=np.cross(p[0]-center,p[1]-center)
        if np.linalg.norm(normal)<1e-8:raise ValueError('Degenerate curve station')
        normal/=np.linalg.norm(normal)
        plane_error=max(abs((p-center)@normal))
        if max(abs(radial-radius))>.05 or plane_error>.05:
            raise ValueError('Freeform sweep cannot be represented by circular pie cuts to 0.05 mm')
        xdir=(start-center)/radius;ydir=np.cross(normal,xdir)
        angles=np.unwrap(np.arctan2((p-center)@ydir,(p-center)@xdir))
        sweep=float(angles[-1]-angles[0])
        if sweep<=0 or sweep>=2*math.pi-.01 or np.any(np.diff(angles)<-1e-4):
            raise ValueError('Ambiguous circular sweep direction')
        segments.append(Segment('arc',tuple(start),tuple(end),radius*sweep,radius,
                                tuple(center),tuple(xdir),tuple(ydir),0,sweep,True))
    for a,b in zip(segments,segments[1:]):
        if dot(a.tangent_end(),b.tangent_start())<.999:
            raise ValueError('Recovered centerline has a tangent discontinuity')
    props=GProp_GProps();BRepGProp.VolumeProperties_s(shape,props)
    expected=math.pi*(outer*outer-inner*inner)*sum(s.length for s in segments)
    if abs(props.Mass()-expected)/expected>.005:
        raise ValueError('Recovered tube contains extra or missing solid features')
    return segments,outer,inner


def read_tube(path):
    rd=STEPControl_Reader()
    if rd.ReadFile(str(path)) != IFSelect_RetDone: raise ValueError('Cannot read STEP file')
    rd.TransferRoots(); shape=rd.OneShape()
    solids=0; solid_explorer=TopExp_Explorer(shape,TopAbs_SOLID)
    while solid_explorer.More():solids+=1;solid_explorer.Next()
    if solids!=1 or not BRepCheck_Analyzer(shape).IsValid():
        raise ValueError('Input must be one valid tube solid, not an assembly')
    faces=[]; e=TopExp_Explorer(shape,TopAbs_FACE)
    while e.More(): faces.append(TopoDS.Face_s(e.Current()));e.Next()
    tor=[];cyl=[];plane=[];spline=[]
    for f in faces:
        a=BRepAdaptor_Surface(f); typ=a.GetType(); u0,u1,v0,v1=BRepTools.UVBounds_s(f)
        if typ==GeomAbs_Torus:
            t=a.Torus();tor.append((t,u0,u1))
        elif typ==GeomAbs_Cylinder:
            c=a.Cylinder();cyl.append((c,v0,v1))
        elif typ==GeomAbs_Plane:plane.append(f)
        elif typ==GeomAbs_BSplineSurface:spline.append(f)
        else:raise ValueError('Unsupported face type; only plain round tube bends and ends are supported')
    if spline and not tor and not cyl and len(plane)==2:
        return read_nurbs_tube(shape,faces)
    if len(plane)!=2 or not tor or not cyl: raise ValueError('Expected one open-ended bent round tube with two planar ends')
    outer=max([t.MinorRadius() for t,_,_ in tor]+[c.Radius() for c,_,_ in cyl])
    inner=min([t.MinorRadius() for t,_,_ in tor]+[c.Radius() for c,_,_ in cyl])
    if inner<=0 or outer-inner<=0 or any(min(abs(r-outer),abs(r-inner))>.02 for r in [t.MinorRadius() for t,_,_ in tor]+[c.Radius() for c,_,_ in cyl]):
        raise ValueError('Tube wall or diameter is not constant')
    # Collect full bend ranges from each half of the outer toroidal faces.
    groups=defaultdict(list)
    for t,u0,u1 in tor:
        if abs(t.MinorRadius()-outer)>.02:continue
        center=vec(t.Location());axis=vec(t.Axis().Direction());R=t.MajorRadius()
        key=tuple(round(x,3) for x in (*center,*axis,R))
        groups[key].append((t,u0,u1))
    segs=[]
    for arr in groups.values():
        t=arr[0][0]; center=vec(t.Location());R=t.MajorRadius()
        xd=vec(t.Position().XDirection());yd=vec(t.Position().YDirection())
        spans=sorted(set((round(u0,6),round(u1,6)) for _,u0,u1 in arr))
        merged=[]
        for lo,hi in spans:
            if merged and lo<=merged[-1][1]+.002: merged[-1]=(merged[-1][0],max(hi,merged[-1][1]))
            else: merged.append((lo,hi))
        if len(merged)==2 and merged[0][0]<.002 and merged[-1][1]>2*math.pi-.002:
            merged=[(merged[-1][0],merged[0][1]+2*math.pi)]
        for lo,hi in merged:
            if hi-lo>math.pi*1.99:raise ValueError('Near-complete ring bend is ambiguous')
            p=arc_point(center,R,xd,yd,lo);q=arc_point(center,R,xd,yd,hi)
            segs.append(Segment('arc',p,q,R*(hi-lo),R,center,xd,yd,lo,hi))
    linekeys=set()
    for c,v0,v1 in cyl:
        if abs(c.Radius()-outer)>.02:continue
        p=add(vec(c.Location()),mul(vec(c.Axis().Direction()),v0));q=add(vec(c.Location()),mul(vec(c.Axis().Direction()),v1))
        key=tuple(round(x,2) for x in (*p,*q))
        if key in linekeys:continue
        linekeys.add(key);segs.append(Segment('line',p,q,dist(p,q)))
    if len(segs)<2:raise ValueError('No usable centerline')
    # Walk the centerline from an unmatched end, with tangent-continuity checks.
    ends=[p for s in segs for p in (s.start,s.end)]
    unmatched=[p for p in ends if sum(close(p,q) for q in ends)==1]
    if len(unmatched)!=2:raise ValueError('Centerline must form one unbranched open path')
    start=min(unmatched) # deterministic; may reverse from the source CAD's intended start
    todo=segs[:];ordered=[];p=start
    while todo:
        matches=[(i,s if close(s.start,p) else s.reversed()) for i,s in enumerate(todo) if close(s.start,p) or close(s.end,p)]
        if len(matches)!=1:raise ValueError('Centerline is disconnected or branched')
        i,s=matches[0];todo.pop(i);ordered.append(s);p=s.end
    for a,b in zip(ordered,ordered[1:]):
        if dot(a.tangent_end(),b.tangent_start())<.999:raise ValueError('Adjacent centerline elements are not tangent')
    props=GProp_GProps();BRepGProp.VolumeProperties_s(shape,props)
    expected=math.pi*(outer**2-inner**2)*sum(s.length for s in ordered)
    if abs(props.Mass()-expected)/expected>.005:raise ValueError('Input contains extra or missing solid features')
    return ordered,outer,inner


def plan(segments,outer,inner,max_step_deg,bridge_depth,root_width,min_land,segment_counts=None):
    wall=outer-inner
    if not (0<bridge_depth<outer) or root_width<=0:raise ValueError('Bridge depth must be between 0 and OD/2, and root width positive')
    hinge_y=outer-bridge_depth
    if root_width<wall:raise ValueError('Root width below wall thickness; increase --root-width')
    E1=unit(sub(segments[0].center,segments[0].start)) if segments[0].kind=='arc' else None
    T=segments[0].tangent_start()
    if E1 is None:
        first=next(s for s in segments if s.kind=='arc')
        E1=unit(sub(first.center,first.start))
    E1=unit(sub(E1,mul(T,dot(E1,T))));E2=unit(cross(T,E1))
    bend_total=sum(s.kind=='arc' for s in segments)
    if segment_counts is not None and len(segment_counts)!=bend_total:
        raise ValueError(f'Expected {bend_total} bend segment counts, got {len(segment_counts)}')
    out=[];station=0.0;row=[];bend_number=0
    for idx,s in enumerate(segments):
        if s.kind=='line':
            row.append({'kind':'straight','source_length_mm':s.length,'stock_start_mm':station,'stock_end_mm':station+s.length})
            station+=s.length;continue
        angle=s.length/s.radius; inside=unit(sub(s.center,s.start));outside=mul(inside,-1)
        bend_number+=1
        phi=math.atan2(dot(outside,E2),dot(outside,E1))
        hinge_radius=s.radius+hinge_y
        count=(segment_counts[bend_number-1] if segment_counts is not None
               else math.ceil(math.degrees(angle)/max_step_deg))
        if count<1:raise ValueError(f'Bend {bend_number}: segment count must be positive')
        if math.degrees(angle)/count>10.0+1e-8:
            raise ValueError(f'Bend {bend_number}: {count} segments make {math.degrees(angle)/count:.2f} deg each; limit is 10 deg')
        delta=angle/count;pitch=2*hinge_radius*math.sin(delta/2)
        wide=root_width+2*(hinge_y+outer)*math.tan(delta/2)
        land=pitch-wide
        if land<min_land:
            raise ValueError(f'Bend {idx+1}: inner-side land {land:.2f} mm < {min_land:.2f} mm; use smaller bridge depth/root width or larger bend radius')
        for j in range(count):
            out.append({'station_mm':station+(j+.5)*pitch,'angle_rad':delta,'hinge_azimuth_rad':phi,'bend':idx+1})
        row.append({'kind':'bend','source_clr_mm':s.radius,'angle_deg':math.degrees(angle),'notches':count,
                    'angle_each_deg':math.degrees(delta),'pitch_mm':pitch,'root_width_mm':root_width,
                    'inside_opening_mm':wide,'minimum_inner_land_mm':land,
                    'hinge_azimuth_deg':math.degrees(phi)%360,'stock_start_mm':station,'stock_end_mm':station+count*pitch})
        station+=count*pitch
        axis=unit(cross(T,inside));T=rotate(T,axis,angle);E1=rotate(E1,axis,angle);E2=rotate(E2,axis,angle)
        if dot(T,s.tangent_end())<.999:raise ValueError('Bend frame transport failed')
    return out,row,station,hinge_y


def parse_segment_counts(value,bend_total):
    if value is None:return None
    try:counts=[int(part.strip()) for part in value.split(',')]
    except ValueError as exc:raise ValueError('--segments needs positive integers such as 12,37,7') from exc
    if len(counts)==1:counts*=bend_total
    if len(counts)!=bend_total or any(c<1 for c in counts):
        raise ValueError(f'--segments needs one positive integer or {bend_total} comma-separated counts')
    return counts


def cut_tool(x,angle,phi,outer,hinge_y,root_width):
    low=-outer-2.0;high=hinge_y
    half0=root_width/2+(high-low)*math.tan(angle/2);half1=root_width/2
    cy,sy=math.cos(phi),math.sin(phi)
    def pt(ax,y,z):return gp_Pnt(x+ax,y*cy-z*sy,y*sy+z*cy)
    z=-outer-2.0;poly=BRepBuilderAPI_MakePolygon()
    for a,y in [(-half0,low),(half0,low),(half1,high),(-half1,high)]:poly.Add(pt(a,y,z))
    poly.Close();face=BRepBuilderAPI_MakeFace(poly.Wire()).Face()
    return BRepPrimAPI_MakePrism(face,gp_Vec(0,2*z*sy,-2*z*cy)).Shape()


def make_model(notches,length,outer,inner,hinge_y,root_width):
    ax=gp_Ax2(gp_Pnt(0,0,0),gp_Dir(1,0,0))
    stock=BRepPrimAPI_MakeCylinder(ax,outer,length).Shape()
    bore=BRepPrimAPI_MakeCylinder(ax,inner,length).Shape()
    hollow=BRepAlgoAPI_Cut(stock,bore);hollow.Build()
    if not hollow.IsDone():raise RuntimeError('Could not make hollow stock')
    comp=TopoDS_Compound();builder=BRep_Builder();builder.MakeCompound(comp)
    for n in notches:builder.Add(comp,cut_tool(n['station_mm'],n['angle_rad'],n['hinge_azimuth_rad'],outer,hinge_y,root_width))
    cut=BRepAlgoAPI_Cut(hollow.Shape(),comp);cut.Build()
    if not cut.IsDone():raise RuntimeError('Boolean notch cut failed')
    result=cut.Shape();e=TopExp_Explorer(result,TopAbs_SOLID);solids=0
    while e.More():solids+=1;e.Next()
    if solids!=1 or not BRepCheck_Analyzer(result).IsValid():raise RuntimeError(f'Cut model invalid or disconnected ({solids} solids)')
    return result


def generate(input_path,out_dir,segments_option=None,max_step_deg=5.0,bridge_depth=3.0,
             root_width=None,min_land=None,material='UNSPECIFIED',progress=None):
    input_path=Path(input_path);out_dir=Path(out_dir)
    if progress:progress('Reading bent STEP')
    segments,outer,inner=read_tube(input_path);wall=outer-inner
    counts=parse_segment_counts(segments_option,sum(s.kind=='arc' for s in segments))
    if counts is None and (max_step_deg<=0 or max_step_deg>10):
        raise ValueError('--max-step-deg must be in (0,10]')
    root=root_width if root_width is not None else wall
    land=min_land if min_land is not None else wall
    notches,rows,length,hinge_y=plan(segments,outer,inner,max_step_deg,bridge_depth,root,land,counts)
    out_dir.mkdir(parents=True,exist_ok=True)
    if progress:progress('Building and validating cut solid')
    model=make_model(notches,length,outer,inner,hinge_y,root)
    if progress:progress('Writing cut STEP')
    writer=STEPControl_Writer();writer.Transfer(model,STEPControl_AsIs)
    dest=out_dir/(input_path.stem+'_KERF_STRAIGHT.step')
    if writer.Write(str(dest))!=IFSelect_RetDone:raise RuntimeError('STEP export failed')
    report={'source':str(input_path),'units':'mm','material':material,'outside_diameter_mm':2*outer,'wall_mm':wall,
            'stock_cut_length_mm':length,'bridge_depth_mm':bridge_depth,'root_width_mm':root,
            'minimum_land_spec_mm':land,'notch_count':len(notches),
            'segments_per_bend':[r['notches'] for r in rows if r['kind']=='bend'],
            'segments':rows,
            'notches':[{'station_mm':n['station_mm'],'hinge_azimuth_deg':math.degrees(n['hinge_azimuth_rad'])%360,'bend':n['bend']} for n in notches],
            'notes':['Preliminary geometry. Confirm stock grade/temper, machine kerf, minimum feature size, and bridge width with laser shop.',
                     'Notches are modeled at nominal finished size; laser shop applies machine kerf compensation.',
                     'Bend in a fixture against a full-size template; tack, check fit, then weld. Qualify a sample before production.',
                     'The STEP contains a straight hollow tube with open V reliefs; all cuts are through the wall.']}
    report_path=out_dir/(input_path.stem+'_cut_report.json')
    report_path.write_text(json.dumps(report,indent=2),encoding='utf-8')
    return {'step':dest,'report':report_path,'report_data':report,'length_mm':length,'notches':len(notches)}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('input',type=Path,help='Bent, open-ended, constant-size round-tube STEP')
    p.add_argument('--out',type=Path,default=Path('kerf_output'))
    p.add_argument('--max-step-deg',type=float,default=5.0)
    p.add_argument('--segments',help='Kerf segments per bend: one count for all bends, or comma-separated counts in bend order (e.g. 12,37,7). Overrides --max-step-deg.')
    p.add_argument('--bridge-depth',type=float,default=3.0,help='Radial depth of retained outside hinge cap, mm')
    p.add_argument('--root-width',type=float,default=None,help='Width at notch root, mm; default wall thickness')
    p.add_argument('--min-land',type=float,default=None,help='Minimum remaining inner-side land between slots, mm; default wall thickness')
    p.add_argument('--material',default='UNSPECIFIED')
    a=p.parse_args()
    result=generate(a.input,a.out,a.segments,a.max_step_deg,a.bridge_depth,a.root_width,a.min_land,a.material)
    print(json.dumps({'step':str(result['step']),'report':str(result['report']),
                      'length_mm':result['length_mm'],'notches':result['notches']},indent=2))

if __name__=='__main__':main()
