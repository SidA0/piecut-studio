"""Convert a bent round-tube STEP to mitered pie cuts and a one-piece snap fixture.

Requires Python 3.10+ and cadquery-ocp. Geometry is in millimeters. The STEP
reader deliberately rejects non-round, branched, featured, or spline tubes.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
import zipfile
from pathlib import Path

from OCP.BRep import BRep_Builder
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common, BRepAlgoAPI_Cut, BRepAlgoAPI_Fuse
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace, BRepBuilderAPI_MakePolygon
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepGProp import BRepGProp
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox, BRepPrimAPI_MakeCylinder, BRepPrimAPI_MakeHalfSpace, BRepPrimAPI_MakePrism
from OCP.Bnd import Bnd_Box
from OCP.IFSelect import IFSelect_RetDone
from OCP.GProp import GProp_GProps
from OCP.GeomAbs import GeomAbs_Plane
from OCP.STEPControl import STEPControl_AsIs, STEPControl_Writer
from OCP.StlAPI import StlAPI_Writer
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS, TopoDS_Compound
from OCP.TopAbs import TopAbs_FACE
from OCP.gp import gp_Ax2, gp_Dir, gp_Pln, gp_Pnt, gp_Vec

import kerf_tube as kt


def pnt(v): return gp_Pnt(*v)
def direction(v): return gp_Dir(*v)


def bool_op(cls,a,b,label):
    op=cls(a,b);op.Build()
    if not op.IsDone():raise RuntimeError(f'{label} boolean failed')
    return op.Shape()


def verify(shape,label,one=True):
    ex=TopExp_Explorer(shape,TopAbs_SOLID);n=0
    while ex.More():n+=1;ex.Next()
    if (one and n!=1) or n<1 or not BRepCheck_Analyzer(shape).IsValid():
        raise RuntimeError(f'{label}: invalid shape or unexpected solid count {n}')
    return shape


def largest_connected_solid(shape):
    ex=TopExp_Explorer(shape,TopAbs_SOLID);solids=[]
    while ex.More():
        solid=TopoDS.Solid_s(ex.Current());props=GProp_GProps()
        BRepGProp.VolumeProperties_s(solid,props)
        solids.append((props.Mass(),solid));ex.Next()
    if not solids:raise RuntimeError('Clearance cut removed the fixture')
    solids.sort(key=lambda pair:pair[0],reverse=True)
    discarded=sum(v for v,_ in solids[1:])
    if discarded>0.01*solids[0][0]:raise RuntimeError(f'Clearance cut detached {discarded:.1f} mm3 of jig features')
    return solids[0][1],discarded


def compound(shapes):
    result=TopoDS_Compound();b=BRep_Builder();b.MakeCompound(result)
    for shape in shapes:b.Add(result,shape)
    return result


def write_step(path,shape):
    wr=STEPControl_Writer();wr.Transfer(shape,STEPControl_AsIs)
    if wr.Write(str(path))!=IFSelect_RetDone:raise RuntimeError(f'Could not export {path}')


def write_stl(path,shape):
    BRepMesh_IncrementalMesh(shape,0.12,False,0.15,True).Perform()
    writer=StlAPI_Writer()
    if not writer.Write(shape,str(path)):raise RuntimeError(f'Could not export {path}')


def halfspace(point,normal,reference):
    plane=gp_Pln(pnt(point),direction(normal))
    face=BRepBuilderAPI_MakeFace(plane,-1000,1000,-1000,1000).Face()
    return BRepPrimAPI_MakeHalfSpace(face,pnt(reference)).Solid()


def tube_between(start,end,normal_start,normal_end,outer,inner,index):
    axis=kt.unit(kt.sub(end,start));length=kt.dist(start,end)
    ext=outer+3
    origin=kt.sub(start,kt.mul(axis,ext))
    ax=gp_Ax2(pnt(origin),direction(axis))
    stock=BRepPrimAPI_MakeCylinder(ax,outer,length+2*ext).Shape()
    bore=BRepPrimAPI_MakeCylinder(ax,inner,length+2*ext).Shape()
    hollow=bool_op(BRepAlgoAPI_Cut,stock,bore,f'piece {index} bore')
    mid=kt.mul(kt.add(start,end),.5)
    first=halfspace(start,normal_start,mid)
    last=halfspace(end,normal_end,mid)
    shape=bool_op(BRepAlgoAPI_Common,hollow,first,f'piece {index} start miter')
    shape=bool_op(BRepAlgoAPI_Common,shape,last,f'piece {index} end miter')
    return verify(shape,f'piece {index}')


def source_end_normals(input_path,segments):
    from OCP.STEPControl import STEPControl_Reader
    reader=STEPControl_Reader()
    if reader.ReadFile(str(input_path))!=IFSelect_RetDone:raise ValueError('Cannot read source end faces')
    reader.TransferRoots();shape=reader.OneShape();faces=[]
    explorer=TopExp_Explorer(shape,TopAbs_FACE)
    while explorer.More():
        face=TopoDS.Face_s(explorer.Current());surface=BRepAdaptor_Surface(face)
        if surface.GetType()==GeomAbs_Plane:
            props=GProp_GProps();BRepGProp.SurfaceProperties_s(face,props)
            center=kt.vec(props.CentreOfMass());normal=kt.vec(surface.Plane().Axis().Direction())
            faces.append((center,normal))
        explorer.Next()
    if len(faces)!=2:raise ValueError('Expected exactly two planar source end faces')
    start,end=segments[0].start,segments[-1].end
    if kt.dist(faces[0][0],start)+kt.dist(faces[1][0],end) > kt.dist(faces[1][0],start)+kt.dist(faces[0][0],end):
        faces.reverse()
    normals=[]
    for (center,normal),point,tangent in zip(faces,(start,end),(segments[0].tangent_start(),segments[-1].tangent_end())):
        if abs(kt.dot(kt.sub(point,center),normal))>.05:
            raise ValueError('Source end face does not pass through recovered centerline endpoint')
        normals.append(normal if kt.dot(normal,tangent)>0 else kt.mul(normal,-1))
    return tuple(normals)


def validate_bend_angles(segments,counts,bend_angles_deg):
    if bend_angles_deg is None:return None
    bends=[s for s in segments if s.kind=='arc']
    if not isinstance(bend_angles_deg,list) or len(bend_angles_deg)!=len(bends):
        raise ValueError('Provide one angle list per bend')
    for i,(angles,s,count) in enumerate(zip(bend_angles_deg,bends,counts),1):
        sweep=math.degrees(s.length/s.radius)
        if not isinstance(angles,list) or len(angles)!=count or any(isinstance(a,bool) or not isinstance(a,(int,float)) or not math.isfinite(a) or a<=0 or a>60 for a in angles):
            raise ValueError(f'Bend {i}: invalid sector angles')
        if abs(sum(angles)-sweep)>.002:raise ValueError(f'Bend {i}: sector angles do not sum to the source sweep')
    return bend_angles_deg


def path_nodes(segments,counts,end_normals=None,bend_angles_deg=None):
    bend_angles_deg=validate_bend_angles(segments,counts,bend_angles_deg)
    nodes=[segments[0].start]
    meta=[];bend=0
    for s in segments:
        if s.kind=='line':
            nodes.append(s.end);meta.append({'kind':'straight','source_length_mm':s.length})
        else:
            count=counts[bend];bend+=1
            if count<1:raise ValueError('All segment counts must be positive')
            if bend_angles_deg is not None:
                angles=bend_angles_deg[bend-1];total=sum(angles)
                fractions=[sum(angles[:j])/total for j in range(1,count+1)]
            else:fractions=None
            for j in range(1,count+1):
                fraction=fractions[j-1] if fractions is not None else j/count
                u=s.u0+(s.u1-s.u0)*fraction if s.forward else s.u1-(s.u1-s.u0)*fraction
                nodes.append(kt.arc_point(s.center,s.radius,s.xdir,s.ydir,u))
                meta.append({'kind':'pie','bend':bend,'segment_in_bend':j,'segments_in_bend':count,
                             'bend_angle_deg':math.degrees(s.length/s.radius),
                             'sector_angle_deg':bend_angles_deg[bend-1][j-1] if bend_angles_deg is not None else math.degrees(s.length/s.radius/count),
                             'miter_nominal_deg':(bend_angles_deg[bend-1][j-1] if bend_angles_deg is not None else math.degrees(s.length/s.radius/count))/2})
    directions=[kt.unit(kt.sub(b,a)) for a,b in zip(nodes,nodes[1:])]
    # Fix both terminal planes to the source tube end faces. Interior miters
    # bisect adjacent chords; neither end accumulates segmentation drift.
    first,last=end_normals or (segments[0].tangent_start(),segments[-1].tangent_end())
    normals=[first]+[kt.unit(kt.add(a,b)) for a,b in zip(directions,directions[1:])]+[last]
    return nodes,directions,normals,meta


def printable_saddle(mid,axis,outer,width,fit_clearance,radial_wall,snap_interference,up=(0.0,0.0,1.0)):
    n=kt.sub(up,kt.mul(axis,kt.dot(up,axis)))
    if kt.norm(n)<.15:raise ValueError('A tube piece is too close to vertical for this z-oriented fixture')
    n=kt.unit(n);b=kt.unit(kt.cross(n,axis))
    r=outer+fit_clearance
    tip_z=.4*outer;shoulder_z=.25*outer
    tip_y=outer-snap_interference/2
    if tip_y<=math.sqrt(outer*outer-tip_z*tip_z)+.05:
        raise ValueError('Snap interference is too large for this tube diameter')
    valley=-math.sqrt(2)*r
    side_z=(1-math.sqrt(2))*r
    # The lower faces of the saddle rise at 45 degrees, then become vertical
    # arms. Only a short, gently sloped lip projects toward the tube.
    outline=[(0,valley-radial_wall),(r+radial_wall,side_z),
             (r+radial_wall,tip_z),(tip_y,tip_z),(r,shoulder_z),
             (r,side_z),(0,valley),(-r,side_z),(-r,shoulder_z),
             (-tip_y,tip_z),(-(r+radial_wall),tip_z),(-(r+radial_wall),side_z)]
    plane_x=kt.sub(mid,kt.mul(axis,width/2))
    polygon=BRepBuilderAPI_MakePolygon()
    for y,z in outline:
        polygon.Add(pnt(kt.add(kt.add(plane_x,kt.mul(b,y)),kt.mul(n,z))))
    polygon.Close()
    face=BRepBuilderAPI_MakeFace(polygon.Wire()).Face()
    saddle=BRepPrimAPI_MakePrism(face,gp_Vec(*kt.mul(axis,width))).Shape()
    return verify(saddle,'printable saddle'),n


def add_id_holes(piece,mid,axis,up,outer,inner,piece_id,bit_angles,hole_diameter):
    side=kt.unit(kt.cross(up,axis))
    cutters=[]
    marks=[(-78.0,hole_diameter+1.0)]
    marks.extend((angle,hole_diameter) for bit,angle in enumerate(bit_angles) if piece_id & (1<<bit))
    for angle,diameter in marks:
        theta=math.radians(angle)
        radial=kt.add(kt.mul(up,math.cos(theta)),kt.mul(side,math.sin(theta)))
        origin=kt.add(mid,kt.mul(radial,outer+1.0))
        cutter=BRepPrimAPI_MakeCylinder(gp_Ax2(pnt(origin),direction(kt.mul(radial,-1))),
                                        diameter/2,outer-inner+2.0).Shape()
        cutters.append(cutter)
    result=bool_op(BRepAlgoAPI_Cut,piece,compound(cutters),f'piece {piece_id} ID holes')
    return verify(result,f'piece {piece_id} with ID holes')


SEGMENTS_BY_DIGIT={
    '0':'abcdef','1':'bc','2':'abdeg','3':'abcdg','4':'bcfg',
    '5':'acdfg','6':'acdefg','7':'abc','8':'abcdefg','9':'abcdfg'}
BAR_BOXES={'a':(.9,6.25,2.2,.7),'b':(3.25,4.0,.7,2.15),'c':(3.25,.9,.7,2.1),
           'd':(.9,.05,2.2,.7),'e':(.05,.9,.7,2.1),'f':(.05,4.0,.7,2.15),
           'g':(.9,3.1,2.2,.7)}


def label_bars(number,center,z):
    shapes=[];left=center[0]-4.5;bottom=center[1]-3.5
    for index,digit in enumerate(f'{number:02d}'):
        for segment in SEGMENTS_BY_DIGIT[digit]:
            x,y,w,h=BAR_BOXES[segment]
            shapes.append(BRepPrimAPI_MakeBox(pnt((left+5*index+x,bottom+y,z-.05)),
                                              w,h,.85).Shape())
    return shapes


def place_labels(post_centers,xmin,xmax,ymin,ymax):
    centroid=(sum(p[0] for p in post_centers)/len(post_centers),
              sum(p[1] for p in post_centers)/len(post_centers))
    placed=[]
    for point in post_centers:
        vx=point[0]-centroid[0];vy=point[1]-centroid[1]
        base_angle=math.atan2(vy,vx)
        choice=None
        for radius in (16,22,29,37,46):
            for turn in (0,1,-1,2,-2,3,-3,4):
                angle=base_angle+turn*math.pi/4
                x=point[0]+radius*math.cos(angle);y=point[1]+radius*math.sin(angle)
                if not (xmin+7<x<xmax-7 and ymin+6<y<ymax-6):continue
                if any(math.hypot(x-p[0],y-p[1])<12 for p in post_centers):continue
                if any(math.hypot(x-p[0],y-p[1])<12 for p in placed):continue
                choice=(x,y);break
            if choice:break
        if choice is None:raise ValueError('Could not place separate raised jig IDs; use a larger base margin')
        placed.append(choice)
    return placed


def write_piece_map_svg(rows,xmin,xmax,ymin,ymax,path,has_jig=True):
    scale=min(880/(xmax-xmin),720/(ymax-ymin))
    width=(xmax-xmin)*scale+120;height=(ymax-ymin)*scale+120
    def xy(point):return ((point[0]-xmin)*scale+60,(ymax-point[1])*scale+60)
    stations=[xy(row['clamp_center_mm']) for row in rows]
    chain=' '.join(f'{x:.1f},{y:.1f}' for x,y in stations)
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width:.1f} {height:.1f}">',
           '<rect width="100%" height="100%" fill="#f3f7fa"/>',
           f'<rect x="60" y="60" width="{(xmax-xmin)*scale:.1f}" height="{(ymax-ymin)*scale:.1f}" fill="#e3ebf0" stroke="#8ba1b2" stroke-width="2"/>',
           f'<polyline points="{chain}" fill="none" stroke="#d27b38" stroke-width="14" stroke-linecap="round" stroke-linejoin="round" opacity=".55"/>']
    for row,station in zip(rows,stations):
        lx,ly=xy(row['jig_label_center_mm_xy']);sx,sy=station
        parts.extend((f'<line x1="{sx:.1f}" y1="{sy:.1f}" x2="{lx:.1f}" y2="{ly:.1f}" stroke="#3a6888" stroke-width="1.5"/>',
                      f'<circle cx="{lx:.1f}" cy="{ly:.1f}" r="13" fill="#215c82"/>',
                      f'<text x="{lx:.1f}" y="{ly+4.5:.1f}" text-anchor="middle" font-family="Arial,sans-serif" font-size="12" font-weight="bold" fill="white">{row["piece"]:02d}</text>'))
    map_name='Top-view jig position map' if has_jig else 'Top-view assembly position map'
    parts.append(f'<text x="60" y="37" font-family="Arial,sans-serif" font-size="18" fill="#183a52">{map_name} · {len(rows)} pieces in path order</text>')
    parts.append('</svg>')
    path.write_text('\n'.join(parts),encoding='utf-8')


def counts_from_option(segments,option,max_angle):
    bends=[s for s in segments if s.kind=='arc']
    if option:return kt.parse_segment_counts(option,len(bends))
    if not 0<max_angle<=60:raise ValueError('--max-angle must be in (0,60] degrees')
    # Prefer a shared pitch for bends of the same radius when their sweeps
    # divide into matching sectors. Among equally standard plans, use fewer cuts.
    counts=[0]*len(bends)
    families=[]
    for i,s in enumerate(bends):
        family=next((f for f in families if abs(f[0][1].radius-s.radius)<.02),None)
        if family is None:families.append([(i,s)])
        else:family.append((i,s))
    for family in families:
        options=[]
        for _,s in family:
            angle=math.degrees(s.length/s.radius)
            lo=max(1,math.ceil(angle/max_angle-1e-9))
            hi=min(32,lo+max(1,int(lo*.25)))
            for n in range(lo,hi+1):options.append(angle/n)
        plans=[]
        for pitch in options:
            ns=[];sectors=[]
            for _,s in family:
                angle=math.degrees(s.length/s.radius)
                lo=max(1,math.ceil(angle/max_angle-1e-9))
                hi=min(32,lo+max(1,int(lo*.25)))
                n=min(hi,max(lo,round(angle/pitch)));ns.append(n);sectors.append(angle/n)
            unique=len({round(a/.05) for a in sectors})
            plans.append((unique,sum(ns),max(sectors),ns))
        best=min(plans,key=lambda p:p[:3])
        for (i,_),n in zip(family,best[3]):counts[i]=n
    return counts


def curve_profiles(segments,counts):
    groups=[];bend=0
    for s in segments:
        if s.kind!='arc':continue
        bend+=1;angle=math.degrees(s.length/s.radius)
        group=next((g for g in groups if abs(g['radius_mm']-s.radius)<.02 and
                    abs(g['sweep_deg']-angle)<.05),None)
        if group is None:
            group={'profile':f'C{len(groups)+1:02d}','radius_mm':s.radius,
                   'sweep_deg':angle,'bends':[],'quantity':0,'segments_each':counts[bend-1]}
            groups.append(group)
        group['bends'].append(bend);group['quantity']+=1
    return groups


def seam_length_mm(radius,miter_deg):
    # Ramanujan's ellipse perimeter for a round tube cut by a miter plane.
    a=radius/math.cos(math.radians(miter_deg));b=radius
    h=((a-b)/(a+b))**2
    return math.pi*(a+b)*(1+3*h/(10+math.sqrt(4-3*h)))


def shape_volume(shape):
    props=GProp_GProps();BRepGProp.VolumeProperties_s(shape,props)
    return props.Mass()


def centerline_error(segments,counts,bend_angles_deg=None):
    bend_angles_deg=validate_bend_angles(segments,counts,bend_angles_deg)
    source_length=sum(s.length for s in segments)
    chord_length=0.0;sum_squared=0.0;maximum=0.0;bend=0
    for s in segments:
        if s.kind=='line':chord_length+=s.length;continue
        count=counts[bend];bend+=1
        sweep=s.u1-s.u0
        fractions=([0]+[sum(bend_angles_deg[bend-1][:j])/sum(bend_angles_deg[bend-1]) for j in range(1,count+1)]
                   if bend_angles_deg is not None else [j/count for j in range(count+1)])
        for j in range(count):
            step=sweep*(fractions[j+1]-fractions[j])
            ua=(s.u0+sweep*fractions[j]) if s.forward else (s.u1-sweep*fractions[j])
            ub=(s.u0+sweep*fractions[j+1]) if s.forward else (s.u1-sweep*fractions[j+1])
            start=kt.arc_point(s.center,s.radius,s.xdir,s.ydir,ua)
            end=kt.arc_point(s.center,s.radius,s.xdir,s.ydir,ub)
            delta=kt.sub(end,start);length=kt.norm(delta);chord_length+=length
            maximum=max(maximum,s.radius*(1-math.cos(abs(step)/2)))
            for k in range(48):
                u=ua+(ub-ua)*(k+.5)/48
                point=kt.arc_point(s.center,s.radius,s.xdir,s.ydir,u)
                fraction=max(0,min(1,kt.dot(kt.sub(point,start),delta)/(length*length)))
                distance=kt.dist(point,kt.add(start,kt.mul(delta,fraction)))
                sum_squared+=distance*distance*(s.radius*abs(step)/48)
    return {'source_centerline_length_mm':source_length,'pie_centerline_length_mm':chord_length,
            'centerline_length_delta_mm':chord_length-source_length,
            'centerline_length_delta_percent':100*(chord_length-source_length)/source_length,
            'centerline_rms_deviation_mm':math.sqrt(sum_squared/source_length),
            'centerline_max_deviation_mm':maximum}


def occupied_volume_error(input_path,assembly):
    from OCP.STEPControl import STEPControl_Reader
    reader=STEPControl_Reader()
    if reader.ReadFile(str(input_path))!=IFSelect_RetDone:raise ValueError('Cannot reread source STEP for volume comparison')
    reader.TransferRoots();original=reader.OneShape()
    intersection=bool_op(BRepAlgoAPI_Common,original,assembly,'source/pie volume overlap')
    source_volume=shape_volume(original);pie_volume=shape_volume(assembly)
    overlap=shape_volume(intersection)
    missing=max(0,source_volume-overlap);extra=max(0,pie_volume-overlap)
    error=missing+extra
    return {'source_wall_volume_mm3':source_volume,'pie_wall_volume_mm3':pie_volume,
            'occupied_volume_error_mm3':error,
            'occupied_volume_error_percent':100*error/source_volume,
            'missing_source_volume_mm3':missing,'excess_pie_volume_mm3':extra,
            'measurement_basis':'Symmetric difference of the original STEP wall solid and all assembled pie-cut wall solids.'}


def piece_profiles(rows,normals,axes,id_holes=False):
    groups=[]
    for i,row in enumerate(rows):
        axis=axes[i]
        va=kt.sub(normals[i],kt.mul(axis,kt.dot(normals[i],axis)))
        vb=kt.sub(normals[i+1],kt.mul(axis,kt.dot(normals[i+1],axis)))
        relative=0.0 if kt.norm(va)<1e-7 or kt.norm(vb)<1e-7 else kt.dot(kt.unit(va),kt.unit(vb))
        signature=(row['chord_length_mm'], min(row['start_miter_deg'],row['end_miter_deg']),
                   max(row['start_miter_deg'],row['end_miter_deg']),relative)
        group=None if id_holes else next((g for g in groups if abs(g['_signature'][0]-signature[0])<.02 and
                    abs(g['_signature'][1]-signature[1])<.05 and
                    abs(g['_signature'][2]-signature[2])<.05 and
                    abs(g['_signature'][3]-signature[3])<.01),None)
        if group is None:
            group={'profile':f'P{len(groups)+1:02d}','quantity':0,'pieces':[],
                   'representative_step':row['laser_step'],'chord_length_mm':signature[0],
                   'end_miters_deg':[signature[1],signature[2]],
                   'relative_bevel_orientation_dot':signature[3],'_signature':signature}
            groups.append(group)
        group['quantity']+=1;group['pieces'].append(row['piece']);row['cut_profile']=group['profile']
    for group in groups:del group['_signature']
    return groups


def jig_fit_issues(segments,counts,outer,weld_access=4.0,end_normals=None,bend_angles_deg=None):
    # The continuous negative channel supports short pieces without requiring
    # a separate seven-millimeter snap collar at every position.
    return []


def generate(input_path,out_dir,segments_option=None,max_angle=27.0,fit_clearance=0.0,
             weld_access=4.0,collar_width=8.0,plate_thickness=8.0,post_radius=5.0,
             snap_interference=0.4,id_holes=False,id_hole_diameter=2.0,make_jig=False,
             bend_angles_deg=None,progress=None):
    input_path=Path(input_path);out_dir=Path(out_dir)
    source,outer,inner=kt.read_tube(input_path)
    end_normals=source_end_normals(input_path,source)
    counts=counts_from_option(source,segments_option,max_angle)
    geometry_error=centerline_error(source,counts,bend_angles_deg)
    maximum_centerline_deviation=geometry_error['centerline_max_deviation_mm']
    nodes,axes,normals,meta=path_nodes(source,counts,end_normals,bend_angles_deg)
    if make_jig:
        fit_issues=jig_fit_issues(source,counts,outer,weld_access,end_normals,bend_angles_deg)
        if fit_issues:
            first=fit_issues[0]
            raise ValueError(f"Experimental jig cannot grip piece {first['piece']}: {first['available_clamp_mm']:.2f} mm is available; 7 mm is required. Turn the jig off or use fewer segments.")
    if make_jig and len(axes)>120:raise ValueError('More than 120 pie pieces makes this jig impractical; reduce segment counts')
    if make_jig and (fit_clearance<0 or fit_clearance>.25):raise ValueError('--fit-clearance must be 0 to 0.25 mm for snap location')
    bit_count=max(1,len(axes).bit_length())
    bit_angles=[0.0] if bit_count==1 else [-55.0+110.0*j/(bit_count-1) for j in range(bit_count)]
    if id_holes:
        if id_hole_diameter<1 or id_hole_diameter>4:
            raise ValueError('--id-hole-diameter must be 1 to 4 mm')
        if outer*math.radians(110/max(1,bit_count-1))-id_hole_diameter<1.0:
            raise ValueError('Tube is too small for separated ID holes at this piece count')
        if outer*math.radians(23)-(id_hole_diameter+.5)<1.0:
            raise ValueError('Tube is too small for the ID clocking hole')
    out_dir.mkdir(parents=True,exist_ok=True)
    pieces_dir=out_dir/'laser_pieces';pieces_dir.mkdir(exist_ok=True)
    pieces=[];collars=[];rows=[];generated=[]
    if progress:progress('cutting',0,len(axes))
    for i,(start,end,axis,row) in enumerate(zip(nodes,nodes[1:],axes,meta),1):
        angle_start=math.degrees(math.acos(max(-1,min(1,kt.dot(normals[i-1],axis)))))
        angle_end=math.degrees(math.acos(max(-1,min(1,kt.dot(axis,normals[i])))))
        if max(angle_start,angle_end)>45:raise ValueError(f'Piece {i}: miter exceeds a 45 degree bevel')
        length=kt.dist(start,end)
        left=0 if i==1 else weld_access+outer*math.tan(math.radians(angle_start))
        right=0 if i==len(axes) else weld_access+outer*math.tan(math.radians(angle_end))
        available=length-left-right
        width=0.0
        mid=kt.add(start,kt.mul(axis,length/2))
        up=(0,0,1) if abs(kt.dot((0,0,1),axis))<.95 else (1,0,0)
        n=kt.unit(kt.sub(up,kt.mul(axis,kt.dot(up,axis))))
        piece=tube_between(start,end,normals[i-1],normals[i],outer,inner,i)
        if id_holes:piece=add_id_holes(piece,mid,axis,n,outer,inner,i,bit_angles,id_hole_diameter)
        path=pieces_dir/f'piece_{i:03d}.step';write_step(path,piece);pieces.append(piece);generated.append(path)
        rows.append({'piece':i,**row,'chord_length_mm':length,'start_miter_deg':angle_start,
                     'end_miter_deg':angle_end,'clamp_width_mm':width if make_jig else 0,
                     'clamp_center_mm':list(mid),'laser_step':str(path.relative_to(out_dir)),
                     'id_binary_lsb_first':''.join('1' if i&(1<<bit) else '0' for bit in range(bit_count))})
        print(f'piece {i}/{len(axes)}: {length:.2f} mm',flush=True)
        if progress:progress('cutting',i,len(axes))
    assembly=compound(pieces)
    if progress:progress('comparing',len(axes),len(axes))
    geometry_error.update(occupied_volume_error(input_path,assembly))
    jig_report={'enabled':False,'experimental':True}
    xmin=min(p[0] for p in nodes)-outer-20;xmax=max(p[0] for p in nodes)+outer+20
    ymin=min(p[1] for p in nodes)-outer-20;ymax=max(p[1] for p in nodes)+outer+20
    if make_jig:
        if progress:progress('jig',len(axes),len(axes))
        import piecut_assembly_jig as aj
        jig_input=out_dir/'_jig_input.step'
        write_step(jig_input,assembly)
        try:
            jig_pieces,jig_runs,jig_analysis=aj.inspect(jig_input)
            jigs,jig_files=aj.make_jigs(jig_pieces,jig_runs,jig_analysis['joints'],out_dir,
                                        fit_clearance,weld_access)
        finally:jig_input.unlink(missing_ok=True)
        generated.extend(jig_files)
        jig_report={'enabled':True,'experimental':True,'part_count':len(jigs),
                    'design':'continuous contoured U-channel with a common flat bottom and terminal alignment stops',
                    'jigs':jigs,'collar_fit_clearance_mm':fit_clearance,
                    'nominal_joint_access_mm':weld_access,
                    'raised_piece_numbers':False,
                    'print_step':jigs[0]['step'],'print_stl':jigs[0]['stl']}
    if progress:progress('exporting',len(axes),len(axes))
    assembly_step=out_dir/'piecut_assembly.step';write_step(assembly_step,assembly)
    assembly_stl=out_dir/'piecut_assembly.stl';write_stl(assembly_stl,assembly)
    generated.extend((assembly_step,assembly_stl))
    max_miter=max(max(r['start_miter_deg'],r['end_miter_deg']) for r in rows)
    profiles=piece_profiles(rows,normals,axes,id_holes)
    unique_dir=out_dir/'unique_profiles';unique_dir.mkdir(exist_ok=True)
    for profile in profiles:
        target=unique_dir/f"{profile['profile']}.step"
        shutil.copyfile(out_dir/profile['representative_step'],target)
        profile['quote_step']=str(target.relative_to(out_dir));generated.append(target)
    for row in rows:
        if 'jig_label_center_mm_xy' not in row:row['jig_label_center_mm_xy']=row['clamp_center_mm'][:2]
    joints=[]
    for i in range(len(rows)-1):
        turn=math.degrees(math.acos(max(-1,min(1,kt.dot(axes[i],axes[i+1])))))
        joints.append({'after_piece':i+1,'before_piece':i+2,'miter_deg':turn/2,
                       'outside_seam_length_mm':seam_length_mm(outer,turn/2)})
    weld_total=sum(j['outside_seam_length_mm'] for j in joints)
    profile_path=out_dir/'cut_profiles.csv'
    with profile_path.open('w',newline='',encoding='utf-8') as file:
        writer=csv.writer(file);writer.writerow(['profile','quantity','pieces','quote_step','chord_length_mm','start_miter_deg','end_miter_deg'])
        for p in profiles:writer.writerow([p['profile'],p['quantity'],' '.join(map(str,p['pieces'])),p['quote_step'],
                                           f"{p['chord_length_mm']:.3f}",f"{p['end_miters_deg'][0]:.3f}",f"{p['end_miters_deg'][1]:.3f}"])
    generated.append(profile_path)
    label_path=out_dir/'piece_index.csv'
    with label_path.open('w',newline='',encoding='utf-8') as file:
        writer=csv.writer(file)
        writer.writerow(['piece','cut_profile','kind','bend','segment_in_bend','chord_length_mm','start_miter_deg',
                         'end_miter_deg','id_binary_lsb_first','laser_step'])
        for row in rows:
            writer.writerow([row['piece'],row['cut_profile'],row['kind'],row.get('bend',''),row.get('segment_in_bend',''),
                             f"{row['chord_length_mm']:.3f}",f"{row['start_miter_deg']:.3f}",
                             f"{row['end_miter_deg']:.3f}",row['id_binary_lsb_first'],row['laser_step']])
    generated.append(label_path)
    map_path=out_dir/'piece_map.svg'
    write_piece_map_svg(rows,xmin,xmax,ymin,ymax,map_path,make_jig);generated.append(map_path)
    curves=curve_profiles(source,counts)
    report={'input':str(input_path),'units':'mm','outside_diameter_mm':2*outer,'wall_mm':outer-inner,
            'segments_per_bend':counts,'bend_angles_deg':bend_angles_deg,
            'piece_count':len(rows),'maximum_miter_deg':max_miter,
            'maximum_centerline_chord_deviation_mm':maximum_centerline_deviation,
            'geometry_error':geometry_error,
            'stock':{'total_tube_length_mm':geometry_error['pie_centerline_length_mm'],
                     'measurement_basis':'Sum of generated piece centerline lengths before fit-up.',
                     'allowance_note':'Net geometric length only. Add purchasing allowance for kerf, chucking, trim, setup, defects, and supplier minimum lengths.'},
            'terminal_planes':{'start':'Original source planar start face','end':'Original source planar end face',
                               'orientation_error_deg':0.0},
            'unique_curve_profile_count':len(curves),'curve_profiles':curves,
            'unique_cut_profile_count':len(profiles),'cut_profiles':profiles,
            'total_pie_cut_count':sum(r['kind']=='pie' for r in rows),
            'total_straight_cut_count':sum(r['kind']=='straight' for r in rows),
            'weld':{'joint_count':len(joints),'expected_full_circumference_mm':weld_total,
                    'expected_half_circumference_mm':weld_total/2,'joints':joints,
                    'method':'Sum of outside miter-plane seam ellipse per adjacent piece pair; no allowance for bead width, gaps, overlap, or distortion.'},
            'physical_piece_id':{'mode':'through_wall_binary_holes' if id_holes else 'none',
                                 'hole_diameter_mm':id_hole_diameter if id_holes else None,
                                 'reference_hole_diameter_mm':id_hole_diameter+1 if id_holes else None,
                                 'reference_hole_angle_deg':-78.0 if id_holes else None,
                                 'bit_angles_deg_lsb_first':bit_angles if id_holes else [],
                                 'note':'The optional holes penetrate one tube wall and may affect pressure tightness and strength. Obtain design and laser-shop approval before using them.' if id_holes else 'Use temporary ink labels or the cut list without altering tube geometry.'},
            'oshcut_preflight':{'status':'REVIEW','single_tube_part_per_step':True,
                                'maximum_miter_deg':max_miter,'published_bevel_limit_deg':45,
                                'catalog_profile_verified':False,
                                'notes':'Choose an orderable OD/wall/material profile and have OSH CUT confirm each miter toolpath.',
                                'sources':['https://www.oshcut.com/design-guide/design-rules',
                                           'https://www.oshcut.com/design-guide/tube-cutting-basics',
                                           'https://www.oshcut.com/design-guide/how-to-order-laser-cut-tube']},
            'jig':jig_report,'pieces':rows,
            'instructions':['Use unique_profiles STEP files and cut_profiles.csv for quantity quoting; laser_pieces retains every assembly position.',
                            'Keep each cut profile identified through quoting and cutting, then map it to the numbered assembly positions in piece_index.csv.',
                            'Read optional physical ID holes using the bit-angle map, or mark unperforated pieces with a removable paint pen immediately after cutting.',
                            'If the experimental jig is enabled, check every joint against the reference STEP and verify channel fit and both terminal stops with a physical sample before tacking.',
                            'For welding while located, use a weld-safe, sufficiently resilient metal jig and heat shields. Weld the accessible half, release the tacked chain, and complete the opposite half in a secondary weld-safe support.',
                            'Ordinary FDM plastic is suitable for cold alignment only. Arc heat can damage it.',
                            'Use stock.total_tube_length_mm as the net tube requirement, then add shop allowance for kerf, chucking, trim, setup, defects, and supplier minimum lengths.',
                            'Verify print tolerance, channel fit, stop clearance, tube-laser stock, bevels, kerf compensation, weld gap, torch clearance, and welding distortion on a trial assembly.']}
    report_path=out_dir/'fabrication_report.json';report_path.write_text(json.dumps(report,indent=2),encoding='utf-8');generated.append(report_path)
    package=out_dir/('piecuts_and_jig.zip' if make_jig else 'piecuts.zip')
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
        for path in generated:z.write(path,path.relative_to(out_dir))
    return report


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input',type=Path)
    ap.add_argument('--out',type=Path,default=Path('piecut_output'))
    ap.add_argument('--segments',help='One count for all bends or comma-separated per bend')
    ap.add_argument('--max-angle',type=float,default=27,help='Maximum bend angle per pie piece, degrees (default 27)')
    ap.add_argument('--fit-clearance',type=float,default=0.0,help='Radial tube-to-clamp CAD allowance, mm')
    ap.add_argument('--weld-access',type=float,default=4.0,help='Nominal axial access from each miter, mm')
    ap.add_argument('--collar-width',type=float,default=8.0,help='Maximum collar length along each piece, mm')
    ap.add_argument('--snap-interference',type=float,default=0.4,help='Tube OD minus collar throat width, mm')
    ap.add_argument('--id-holes',action='store_true',help='Add a unique through-wall binary hole pattern to every tube piece')
    ap.add_argument('--id-hole-diameter',type=float,default=2.0,help='Optional ID hole diameter in mm (default 2)')
    ap.add_argument('--jig',action='store_true',help='Experimental: generate the one-piece printable jig')
    a=ap.parse_args()
    report=generate(a.input,a.out,a.segments,a.max_angle,a.fit_clearance,a.weld_access,a.collar_width,
                    snap_interference=a.snap_interference,id_holes=a.id_holes,id_hole_diameter=a.id_hole_diameter,
                    make_jig=a.jig)
    print(json.dumps({'output':str(a.out),'pieces':report['piece_count'],'counts':report['segments_per_bend'],
                      'maximum_miter_deg':report['maximum_miter_deg'],
                      'maximum_centerline_chord_deviation_mm':report['maximum_centerline_chord_deviation_mm'],
                      'unique_curve_profiles':report['unique_curve_profile_count'],
                      'unique_cut_profiles':report['unique_cut_profile_count'],
                      'weld_length_mm':report['weld']['expected_full_circumference_mm']},indent=2))


if __name__=='__main__':main()
