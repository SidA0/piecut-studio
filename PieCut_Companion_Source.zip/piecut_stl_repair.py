"""Close small planar gaps left by OpenCascade's STL triangulation.

The STEP solid is authoritative. This only repairs missing planar mesh faces;
it rejects nonplanar or ambiguous holes instead of shipping an open STL.
"""
from __future__ import annotations

from collections import Counter,defaultdict
from pathlib import Path
import numpy as np


def _key(point):return tuple(round(float(x),3) for x in point)


def _mesh(path):
    points=[]
    for line in Path(path).read_text(encoding='ascii').splitlines():
        words=line.split()
        if words and words[0]=='vertex':points.append(tuple(map(float,words[1:4])))
    if not points or len(points)%3:raise ValueError('Could not parse triangular ASCII STL')
    return np.array(points,float).reshape(-1,3,3)


def _boundary(triangles):
    count=Counter();oriented={};actual={}
    for tri in triangles:
        keys=[_key(p) for p in tri]
        for p,k in zip(tri,keys):actual.setdefault(k,p)
        for i in range(3):
            a,b=keys[i],keys[(i+1)%3];edge=tuple(sorted((a,b)))
            count[edge]+=1;oriented[edge]=(a,b)
    if any(n>2 for n in count.values()):raise ValueError('STL has nonmanifold edges')
    return [(oriented[e],actual) for e,n in count.items() if n==1]


def _loops(edges):
    remaining=set(edge for edge,_ in edges);out=defaultdict(list)
    for a,b in remaining:out[a].append(b)
    loops=[]
    while remaining:
        start,next_node=min(remaining);path=[start,next_node];remaining.remove((start,next_node))
        while path[-1]!=start:
            node=path[-1];options=[b for b in out[node] if (node,b) in remaining]
            if not options:raise ValueError('STL boundary is not a closed loop')
            if len(options)>1:
                # A shared corner can join two small holes. Follow the edge
                # with the least turn to keep their loops separate.
                prev=np.array(path[-2]);here=np.array(node)
                options.sort(key=lambda b:np.dot((here-prev)/max(np.linalg.norm(here-prev),1e-9),
                                                 (np.array(b)-here)/max(np.linalg.norm(np.array(b)-here),1e-9)),reverse=True)
            next_node=options[0];path.append(next_node);remaining.remove((node,next_node))
            if len(path)>len(edges)+1:raise ValueError('STL boundary loop did not close')
        loops.append(path[:-1])
    return loops


def _inside(point,a,b,c,eps=1e-9):
    def cross(u,v,w):return (v[0]-u[0])*(w[1]-u[1])-(v[1]-u[1])*(w[0]-u[0])
    return min(cross(a,b,point),cross(b,c,point),cross(c,a,point))>eps


def _strip_patch(vertices,uv,area):
    n=len(vertices);low=int(np.argmin(uv[:,0]));high=int(np.argmax(uv[:,0]))
    def chain(step):
        sequence=[low];i=low
        while i!=high:
            i=(i+step)%n;sequence.append(i)
        return sequence
    a,b=chain(1),chain(-1);i=j=0;faces=[]
    while i<len(a)-1 or j<len(b)-1:
        if i==len(a)-1:advance_a=False
        elif j==len(b)-1:advance_a=True
        else:advance_a=uv[a[i+1],0]<=uv[b[j+1],0]
        if advance_a:
            tri=(a[i],a[i+1],b[j]);i+=1
        else:
            tri=(a[i],b[j+1],b[j]);j+=1
        if len(set(tri))<3:continue
        p,q,r=uv[list(tri)];cross=(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
        if abs(cross)<1e-12:continue
        if cross*area>0:tri=tri[::-1]
        faces.append(vertices[list(tri)])
    return faces


def _fill(loop,actual):
    vertices=np.array([actual[k] for k in loop]);origin=vertices.mean(axis=0)
    _,singular,vh=np.linalg.svd(vertices-origin,full_matrices=False)
    if singular[-1]>.02:raise ValueError('STL contains a nonplanar boundary hole')
    uv=(vertices-origin)@vh[:2].T
    area=sum(uv[i,0]*uv[(i+1)%len(uv),1]-uv[(i+1)%len(uv),0]*uv[i,1] for i in range(len(uv)))
    order=list(range(len(loop)))
    if area<0:order.reverse()
    attempts=[0]
    def clip(indices):
        attempts[0]+=1
        if attempts[0]>20000:return None
        if len(indices)==3:
            a,b,c=uv[indices]
            if (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])<=1e-12:return None
            return [tuple(indices)]
        for position in range(len(indices)):
            i,j,k=[indices[(position+offset)%len(indices)] for offset in (-1,0,1)]
            a,b,c=uv[[i,j,k]]
            cross=(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
            if cross<=1e-12:continue
            if any(_inside(uv[m],a,b,c) for m in indices if m not in (i,j,k)):continue
            rest=clip(indices[:position]+indices[position+1:])
            if rest is not None:return [(i,j,k)]+rest
        return None
    triangles=clip(order)
    if triangles is None:
        return _strip_patch(vertices,uv,area)
    # Existing boundary triangles follow `loop`; the patch must wind opposite.
    patch=[vertices[list(tri)] for tri in triangles]
    if area>0:patch=[tri[::-1] for tri in patch]
    return patch


def repair(path):
    path=Path(path);raw=_mesh(path)
    mesh=np.array([tri for tri in raw if len({_key(p) for p in tri})==3])
    boundary=_boundary(mesh)
    if not boundary and len(mesh)==len(raw):return 0
    patch=[]
    if boundary:
        actual=boundary[0][1]
        for loop in _loops(boundary):patch.extend(_fill(loop,actual))
    from io import StringIO
    file=StringIO();file.write('solid repaired_jig\n')
    try:
        for tri in list(mesh)+patch:
            normal=np.cross(tri[1]-tri[0],tri[2]-tri[0]);normal/=max(np.linalg.norm(normal),1e-12)
            file.write('facet normal '+' '.join(f'{x:.9g}' for x in normal)+'\n outer loop\n')
            for point in tri:file.write('  vertex '+' '.join(f'{x:.9g}' for x in point)+'\n')
            file.write(' endloop\nendfacet\n')
        file.write('endsolid repaired_jig\n')
    finally:
        addition=file.getvalue();file.close()
    path.write_text(addition,encoding='ascii')
    if _boundary(_mesh(path)):raise ValueError('STL repair left open boundary edges')
    return len(patch)
