# Pie-cut tube generator and optional one-piece fixture

`piecut_jig.py` reads a bent round-tube STEP, replaces each circular bend with selectable straight chords, and cuts each chord to a matching miter plane. It writes one STEP per unique cut profile with a quantity schedule, plus a STEP for every assembly position. The **experimental one-piece jig** is available with `--jig` and is off by default. The source STEP and outputs use millimeters.

## Run

Use Python 3.12 on Windows and install the CAD dependency:

```powershell
py -3.12 -m pip install -r PieCut_requirements.txt
py -3.12 piecut_jig.py "C:\path\to\bent_tube.step" --out "C:\path\to\piecut_output"
```

Keep `piecut_jig.py`, `piecut_assembly_jig.py`, `piecut_stl_repair.py`, and `kerf_tube.py` in the same directory. Set custom counts with `--segments 3,7,2` (one number per bend, in path order), or use one number for every bend. By default, the script chooses counts that keep each bend piece at or below 27 degrees and seeks repeatable angular pitch on matching radii. Add `--jig` to generate the one-piece fixture. `--fit-clearance` controls radial clearance in the U-channel; default zero. The older `--snap-interference`, `--weld-access`, and `--collar-width` arguments remain accepted for compatibility but do not change the new channel geometry.

To add a **unique physical ID** to every tube piece, run with `--id-holes`. This makes a binary pattern of 2 mm through-wall holes on the upper side of each piece, plus a 3 mm reference hole that indicates which end of the pattern to read first. The pattern is visible while the piece is in its saddle. `piece_index.csv` and `fabrication_report.json` show the bit order and hole angles. This option changes the tube: do not use it if the part must remain pressure tight or if the holes are unacceptable for strength, corrosion, or appearance. Ask the tube-laser shop to accept the hole size and spacing. Without `--id-holes`, the cut pieces are unperforated; mark them with a removable paint pen after cutting. Geometrically identical pieces may be interchanged.

The sample `Left Primary.STEP` uses 3,7,2 segments, giving 12 pie cuts and 2 straight sections. Its output report records the current unique profile count, miter angles, weld length, and centerline error. With `--jig`, check `print_envelope_mm` for the required print volume.

Both terminal cut planes are anchored to the source tube's actual planar end faces; internal miter planes bisect adjacent piece axes. The report includes centerline RMS/max interpolation deviation, centerline length delta, and the symmetric difference of the source and assembled wall volumes. The volume difference is divided by source wall volume, so it can exceed 100% for thin walls; use it to compare segment-count choices, not as scrap volume. More segments can reduce geometric error while adding welds and shortening jig grip sections.

## Outputs

- `unique_profiles/P##.step`: one representative STEP per **distinct cut profile** for quantity quoting.
- `cut_profiles.csv`: quantities and assembly positions for each distinct profile.
- `laser_pieces/piece_###.step`: mitered cut at every assembly position.
- `piecut_assembly.step` and `.stl`: assembled target for viewing and measurement, not a laser-cut part.
- `RUN_01_ONE_PIECE_JIG.step` and `.stl` when `--jig` is selected: a **single solid, continuous U-channel** for the tube run. Its underside lies on one flat print plane. Flat walls at the two terminal planes stop axial movement; the channel locates the tube radially while its upper half remains open for tacking. Use `piece_index.csv` and temporary marks to track positions.
- `piece_index.csv`: the piece-to-profile map, lengths, miter angles, and optional hole codes.
- `piece_map.svg`: a top-view drawing with numbered assembly positions (jig positions when enabled).
- `fabrication_report.json`: curve groups, cut profile groups, quantities, weld lengths, chord lengths, miter angles, endpoint plane status, centerline and volume error, dimensions, and process notes.
- `piecuts.zip`, or `piecuts_and_jig.zip` with `--jig`: the complete output set.

## Optional fixture sequence (`--jig`)

1. Print one trial jig, measure the tube OD, and test the channel fit and both end-stop clearances on sacrificial pieces. Adjust `--fit-clearance` for the chosen printer, material, and measured tube.
2. Match each piece file or optional hole code to `piece_index.csv`. Place the pieces in the channel in path order, seating adjoining miters and both terminal faces against their stops. Use removable clamps if upward restraint is required. Check the assembly against the original bent STEP.
3. For welding in the fixture, use a **weld-safe metal print** and heat shields. Tack and weld the accessible upper half circumference with balanced passes. Remove the tacked chain and complete the opposite half in a secondary weld-safe support. Recheck dimensions after cooling.

Ordinary FDM plastic is suitable for cold alignment and fit-up only. It can soften or burn during tacking and welding. The common underside is flat in the reported `print_axis` direction, but nonplanar tube runs can make the walls tall and some upper contours may need print supports. Inspect the STL in your slicer. The channel has 3.75 mm nominal solid material behind each terminal seat. Torch access, shielding, weld shrinkage, and fixture stiffness require a physical trial before production. The one-solid CAD and watertight STL were checked, but this design does not establish weld strength or a qualified welding procedure.

The script accepts one valid, open-ended, constant-wall round-tube solid whose path consists of straight lines and circular arcs. It recognizes both analytic STEP surfaces and rational B-spline patches that reconstruct to lines and circular arcs within 0.05 mm. It rejects branched tubes, genuinely freeform splines, other cross sections, and added features rather than issuing an unreliable cut file. The 3D printed fixture may need print supports and post-processing depending on the chosen process.

## OSH CUT quoting

The script keeps every pie cut in its own STEP file. It checks that miter angles remain below the published 45-degree bevel capacity, but its report stays `REVIEW` until the exact [catalog profile](https://www.oshcut.com/materials) and toolpaths are accepted. See OSH CUT's [tube design rules](https://www.oshcut.com/design-guide/design-rules), [tube cutting basics](https://www.oshcut.com/design-guide/tube-cutting-basics), and [ordering guidance](https://www.oshcut.com/design-guide/how-to-order-laser-cut-tube).
