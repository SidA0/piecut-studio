"""Isolated CAD generation worker for the local website."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import piecut_multibody as multi
from piecut_web import prepare,resolve_plan


def main():
    path=Path(sys.argv[1]);opts=json.loads(sys.argv[2])
    progress_sequence=0
    def update(phase,percent,completed=None,total=None):
        nonlocal progress_sequence
        value={'phase':phase,'percent':round(min(100,max(0,percent)),1),
               'completed':completed,'total':total}
        progress_sequence+=1
        # Windows may hold a progress file open while the web server reads it.
        # Each update gets its own name so no in-use file needs replacing.
        try:
            (path.parent/f'progress_{progress_sequence:06d}.json').write_text(json.dumps(value),encoding='utf-8')
        except OSError:
            pass  # Status reporting must never stop the CAD package.
    update('Reading and validating selected tubes',1)
    _,contexts=prepare(path,opts)
    update('Planning cut geometry',4)
    counts,angles,standardization=resolve_plan(contexts,opts)
    multi.generate_selected(contexts,counts,path.parent/'result',
        max_angle=float(opts.get('max_angle',27)),jig=bool(opts.get('jig',False)),
        id_holes=bool(opts.get('id_holes',False)),bend_angles=angles,
        standardization=standardization,progress=update)
    update('Package ready',100)


if __name__=='__main__':main()
