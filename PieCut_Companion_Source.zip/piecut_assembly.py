"""Combine the positioned laser pieces in a pie-cut package into one STEP assembly.

Each laser_pieces/piece_NNN.step already uses the source STEP's world coordinates.
No placement transform is applied while building the body and piece hierarchy.
"""
from __future__ import annotations

import argparse
from pathlib import Path

from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPCAFControl import STEPCAFControl_Writer
from OCP.STEPControl import STEPControl_Reader
from OCP.TCollection import TCollection_ExtendedString
from OCP.TDataStd import TDataStd_Name
from OCP.TDocStd import TDocStd_Document
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.TopLoc import TopLoc_Location
from OCP.XCAFDoc import XCAFDoc_DocumentTool


def read_piece(path: Path):
    reader = STEPControl_Reader()
    if reader.ReadFile(str(path)) != IFSelect_RetDone or not reader.TransferRoots():
        raise ValueError(f"Could not read {path}")
    shape = reader.OneShape()
    solids = 0
    explorer = TopExp_Explorer(shape, TopAbs_SOLID)
    while explorer.More():
        solids += 1
        explorer.Next()
    if solids != 1:
        raise ValueError(f"Expected one solid in {path}, found {solids}")
    return shape


def write_complete_assembly(package_dir: Path, output: Path | None = None,
                            body_ids: list[int] | None = None) -> tuple[Path, int, int]:
    package_dir = Path(package_dir)
    output = Path(output) if output is not None else package_dir / "all_piecuts_assembly.step"
    body_dirs = ([package_dir / f"body_{body_id:03d}" for body_id in body_ids]
                 if body_ids is not None else
                 sorted(p for p in package_dir.glob("body_[0-9][0-9][0-9]") if p.is_dir()))
    if not body_dirs:
        raise ValueError(f"No body_### folders found in {package_dir}")
    if any(not body_dir.is_dir() for body_dir in body_dirs):
        raise ValueError("A selected body folder is missing from the package")

    document = TDocStd_Document(TCollection_ExtendedString("BinXCAF"))
    shapes = XCAFDoc_DocumentTool.ShapeTool_s(document.Main())
    root = shapes.NewShape()
    TDataStd_Name.Set_s(root, TCollection_ExtendedString("Complete pie-cut assembly"))
    piece_count = 0
    for body_dir in body_dirs:
        piece_files = sorted((body_dir / "laser_pieces").glob("piece_[0-9][0-9][0-9].step"))
        if not piece_files:
            raise ValueError(f"No laser pieces found in {body_dir}")
        body = shapes.NewShape()
        TDataStd_Name.Set_s(body, TCollection_ExtendedString(body_dir.name))
        body_instance = shapes.AddComponent(root, body, TopLoc_Location())
        TDataStd_Name.Set_s(body_instance, TCollection_ExtendedString(body_dir.name))
        for piece_file in piece_files:
            piece = read_piece(piece_file)
            label = shapes.AddComponent(body, piece)
            TDataStd_Name.Set_s(label, TCollection_ExtendedString(f"{body_dir.name}_{piece_file.stem}"))
            piece_count += 1

    shapes.UpdateAssemblies()
    output.parent.mkdir(parents=True, exist_ok=True)
    writer = STEPCAFControl_Writer()
    writer.SetNameMode(True)
    if not writer.Transfer(document) or writer.Write(str(output)) != IFSelect_RetDone:
        raise RuntimeError(f"Could not write {output}")
    return output, len(body_dirs), piece_count


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package_dir", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    path, bodies, pieces = write_complete_assembly(args.package_dir, args.output)
    print(f"Wrote {path} with {bodies} tube bodies and {pieces} positioned pieces")
