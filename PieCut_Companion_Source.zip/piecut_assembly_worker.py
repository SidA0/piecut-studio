"""CAD subprocess for an uploaded, already positioned pie-cut assembly."""
import json
import sys
from pathlib import Path
import piecut_assembly_jig as assembly

path=Path(sys.argv[1]);options=json.loads(sys.argv[2])
report=assembly.package(path,path.parent/'result',make_jig=bool(options.get('jig',True)))
print(json.dumps({'pieces':report['piece_count'],'joints':report['joint_count']}))
