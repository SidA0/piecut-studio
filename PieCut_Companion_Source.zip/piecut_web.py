"""Local browser interface for the STEP pie-cut generator.

Run with the same Python environment used for piecut_jig.py. Binds only to
127.0.0.1 so uploaded CAD never leaves this computer.
"""
from __future__ import annotations

import base64
import binascii
import json
import os
import subprocess
import sys
import threading
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

import kerf_tube as kt
import piecut_jig as pc
import piecut_multibody as multi
import piecut_assembly_jig as assembly_jig

ROOT=Path(__file__).resolve().parent
SITE=ROOT/'piecut_site'
JOBS=ROOT/'web_jobs'
MAX_BYTES=50*1024*1024
PUBLIC_ORIGINS={
    'https://piecut-studio.utexas.chatgpt.site',
    'https://sida0.github.io',
}
job_state={}
state_lock=threading.Lock()
cad_lock=threading.Lock()


def payload(raw):
    name=str(raw.get('filename','')).strip()
    if Path(name).suffix.lower() not in ('.step','.stp'):
        raise ValueError('Choose a .step or .stp file.')
    try:data=base64.b64decode(raw.get('data',''),validate=True)
    except (ValueError,binascii.Error) as exc:raise ValueError('Invalid upload data.') from exc
    if not data or len(data)>MAX_BYTES:raise ValueError('CAD file must be between 1 byte and 50 MB.')
    return data


def prepare(path,opts):
    bodies=multi.extract_bodies(path,path.parent/'bodies')
    selected=multi.select_bodies(bodies,opts.get('selected_bodies'))
    return bodies,multi.contexts(selected)


def resolve_plan(contexts,opts):
    max_angle=float(opts.get('max_angle',27))
    if opts.get('experimental_standard_radius'):
        if opts.get('id_holes'):
            raise ValueError('Turn off physical ID holes to reuse standard radius cuts.')
        plan=multi.standard_radius_plan(contexts,max_angle,float(opts.get('profile_weight',5)))
        return plan['counts'],plan['bend_angles_deg'],plan
    counts=multi.count_map(contexts,opts.get('segments'),max_angle)
    return counts,multi.angle_map(contexts,counts,opts.get('bend_angles')),None


def analyze(path,opts):
    bodies,contexts=prepare(path,opts)
    counts,angles,standardization=resolve_plan(contexts,opts)
    bends=[];issues=[];curves=[]
    for bi,(c,row) in enumerate(zip(contexts,counts)):
        for i,s in enumerate(c['bends']):
            bends.append({'body':c['body'],'bend':i+1,'radius_mm':s.radius,
                          'sweep_deg':s.length/s.radius*180/3.141592653589793,
                          'recommended_segments':row[i]})
        issues.extend({'body':c['body'],**issue} for issue in pc.jig_fit_issues(c['segments'],row,c['outer'],end_normals=c['end_normals'],
                                    bend_angles_deg=angles[bi] if angles is not None else None))
        curves.extend({'body':c['body'],**curve} for curve in pc.curve_profiles(c['segments'],row))
    result={'units':'mm','bodies':[{k:v for k,v in b.items() if k!='step_path'} for b in bodies],
            'selected_body_ids':[c['body'] for c in contexts],
            'selected_body_count':len(contexts),'bend_count':len(bends),
            'straight_count':sum(sum(s.kind=='line' for s in c['segments']) for c in contexts),
            'recommended_segments':[n for row in counts for n in row],
            'counts_per_body':counts,'bend_angles_per_body':angles,
            'recommended_total_pie_cuts':sum(map(sum,counts)),
            'jig_fit_issues':issues,'curve_profiles':curves,'bends':bends,
            'plan_metrics':multi.plan_metrics(contexts,counts,bend_angles=angles),
            'preview':multi.preview_data(contexts,counts,bend_angles=angles),
            'standardization':standardization}
    if opts.get('trade_study'):
        result['trade_study']=multi.trade_study(contexts,counts,float(opts.get('max_angle',27)),angles)
    return result


def run_job(job_id,path,opts,assembly=False):
    try:
        environment=os.environ.copy()
        vendor=ROOT.parent/'work'/'vendor'
        if (vendor/'OCP').exists():
            environment['PYTHONPATH']=os.pathsep.join([str(vendor),str(ROOT),environment.get('PYTHONPATH','')])
        worker='piecut_assembly_worker.py' if assembly else 'piecut_worker.py'
        process=subprocess.run([sys.executable,str(ROOT/worker),str(path),json.dumps(opts)],
                               capture_output=True,text=True,timeout=1800,cwd=str(ROOT),env=environment)
        if process.returncode:
            detail=(process.stderr or process.stdout).strip().splitlines()
            raise RuntimeError(detail[-1] if detail else f'CAD worker exited {process.returncode}')
        report_name='assembly_weld_report.json' if assembly else 'fabrication_report.json'
        result=json.loads((path.parent/'result'/report_name).read_text(encoding='utf-8'))
        with state_lock:job_state[job_id]={'status':'done','report':result,
            'download':f'/api/jobs/{job_id}/download','assembly':assembly}
    except Exception as exc:
        with state_lock:job_state[job_id]={'status':'error','error':str(exc)}


class Handler(BaseHTTPRequestHandler):
    def end_headers(self):
        origin=self.headers.get('Origin','')
        if origin in PUBLIC_ORIGINS:
            self.send_header('Access-Control-Allow-Origin',origin)
            self.send_header('Access-Control-Allow-Private-Network','true')
            self.send_header('Vary','Origin')
        super().end_headers()

    def do_OPTIONS(self):
        if self.headers.get('Origin') not in PUBLIC_ORIGINS:
            self.send_response(403);self.end_headers();return
        self.send_response(204)
        self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type')
        self.send_header('Access-Control-Max-Age','600')
        self.end_headers()

    def json(self,obj,status=200):
        body=json.dumps(obj).encode('utf-8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store')
        self.end_headers();self.wfile.write(body)

    def do_POST(self):
        route=urlparse(self.path).path
        if self.headers.get('Origin') not in (None,*PUBLIC_ORIGINS):
            self.json({'error':'Origin not allowed'},403);return
        if route not in ('/api/analyze','/api/solve','/api/generate','/api/assembly/analyze','/api/assembly/generate'):
            self.json({'error':'Not found'},404);return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length<1 or length>MAX_BYTES*2:self.json({'error':'Upload is too large.'},413);return
            request=json.loads(self.rfile.read(length))
            data=payload(request)
            options=request.get('options') or {}
            if not isinstance(options,dict):raise ValueError('Invalid options.')
            if not route.startswith('/api/assembly/'):
                max_angle=float(options.get('max_angle',27))
                if not 0<max_angle<=60:raise ValueError('Maximum angle must be above 0 and at most 60°.')
            job_id=uuid.uuid4().hex
            folder=JOBS/job_id;folder.mkdir(parents=True,exist_ok=False)
            input_file=folder/('upload'+Path(str(request.get('filename'))).suffix.lower())
            input_file.write_bytes(data)
            if route=='/api/assembly/analyze':
                with cad_lock:_,_,result=assembly_jig.inspect(input_file)
                self.json(result);return
            if route=='/api/assembly/generate':
                with state_lock:job_state[job_id]={'status':'working','assembly':True}
                threading.Thread(target=run_job,args=(job_id,input_file,options,True),daemon=True).start()
                self.json({'job_id':job_id,'status':'working'},202);return
            if route=='/api/analyze':
                with cad_lock:result=analyze(input_file,options)
                self.json(result);return
            if route=='/api/solve':
                if options.get('id_holes'):raise ValueError('Turn off physical ID holes to optimize reusable cut profiles')
                if options.get('experimental_standard_radius'):
                    raise ValueError('Turn off experimental standard middle cuts before using the shared cut solver.')
                with cad_lock:
                    _,contexts=prepare(input_file,options)
                    result=multi.optimize(contexts,max_angle,
                        float(options.get('profile_weight',5)),int(options.get('extra_segments',4)))
                self.json(result);return
            with state_lock:job_state[job_id]={'status':'working'}
            thread=threading.Thread(target=run_job,args=(job_id,input_file,options),daemon=True)
            thread.start();self.json({'job_id':job_id,'status':'working'},202)
        except (ValueError,TypeError,KeyError) as exc:self.json({'error':str(exc)},400)
        except Exception as exc:self.json({'error':str(exc)},500)

    def do_GET(self):
        route=urlparse(self.path).path
        if route=='/api/health':
            self.json({'status':'ready','engine':'local','accepts':['.step','.stp']});return
        if route in ('/','/index.html','/app.css','/app.js','/preview.js','/assembly.js'):
            file=SITE/('index.html' if route=='/' else route.lstrip('/'))
            kind={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8',
                  '.js':'text/javascript; charset=utf-8'}[file.suffix]
            body=file.read_bytes();self.send_response(200);self.send_header('Content-Type',kind)
            self.send_header('Cache-Control','no-store')
            self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body);return
        parts=route.strip('/').split('/')
        if len(parts) in (3,4) and parts[:2]==['api','jobs']:
            job_id=parts[2]
            with state_lock:state=job_state.get(job_id)
            if state is None:self.json({'error':'Job not found'},404);return
            if len(parts)==3:
                if state['status']=='working':
                    for progress_file in sorted((JOBS/job_id).glob('progress_*.json'),reverse=True)[:3]:
                        try:
                            state={**state,'progress':json.loads(progress_file.read_text(encoding='utf-8'))}
                            break
                        except (ValueError,OSError):pass
                self.json(state);return
            if parts[3]=='download' and state['status']=='done':
                folder=JOBS/job_id/'result'
                file=folder/('assembly_weld_and_jigs.zip' if state.get('assembly') else 'piecuts_multi_body.zip')
                body=file.read_bytes();self.send_response(200)
                self.send_header('Content-Type','application/zip')
                prefix='assembly_jigs' if state.get('assembly') else 'piecuts'
                self.send_header('Content-Disposition',f'attachment; filename="{prefix}_{job_id[:8]}.zip"')
                self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body);return
        self.json({'error':'Not found'},404)


def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args()
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
    url=f'http://127.0.0.1:{args.port}/'
    print(f'Pie-cut website: {url}',flush=True)
    if not args.no_browser:threading.Timer(.8,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()


if __name__=='__main__':main()
